package org.xtext.game.mygame.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.game.mygame.services.MyGamesGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyGamesParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_NUMBER", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Mainwindow'", "'('", "','", "')'", "'Main'", "';'", "'Character'", "'['", "']'", "'Player'", "'Obstacle'", "'GameProps'", "'Destination'", "'='", "'Var'", "'int'", "'Trigger'", "'UP'", "'DOWN'", "'LEFT'", "'RIGHT'", "'{'", "'}'", "'.'", "'if'", "'else'", "'for'", "'=='", "'<'", "'+'", "'-'", "'/'", "'*'", "'!'"
    };
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=8;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=7;
    public static final int RULE_SL_COMMENT=9;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=10;
    public static final int RULE_ANY_OTHER=11;
    public static final int RULE_NUMBER=5;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalMyGamesParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyGamesParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyGamesParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyGames.g"; }



     	private MyGamesGrammarAccess grammarAccess;

        public InternalMyGamesParser(TokenStream input, MyGamesGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Minigames";
       	}

       	@Override
       	protected MyGamesGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleMinigames"
    // InternalMyGames.g:64:1: entryRuleMinigames returns [EObject current=null] : iv_ruleMinigames= ruleMinigames EOF ;
    public final EObject entryRuleMinigames() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMinigames = null;


        try {
            // InternalMyGames.g:64:50: (iv_ruleMinigames= ruleMinigames EOF )
            // InternalMyGames.g:65:2: iv_ruleMinigames= ruleMinigames EOF
            {
             newCompositeNode(grammarAccess.getMinigamesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMinigames=ruleMinigames();

            state._fsp--;

             current =iv_ruleMinigames; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMinigames"


    // $ANTLR start "ruleMinigames"
    // InternalMyGames.g:71:1: ruleMinigames returns [EObject current=null] : (otherlv_0= 'Mainwindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ( (lv_DeclarationSet_7_0= ruleVariableDeclaration ) )* otherlv_8= 'Main' ( (lv_Constructor_9_0= ruleNormalStatementBlock ) ) ( (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock ) )* ) ;
    public final EObject ruleMinigames() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        EObject lv_Formalparameter_3_0 = null;

        EObject lv_Formalparameter_5_0 = null;

        EObject lv_DeclarationSet_7_0 = null;

        EObject lv_Constructor_9_0 = null;

        EObject lv_KeyPressEvents_10_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:77:2: ( (otherlv_0= 'Mainwindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ( (lv_DeclarationSet_7_0= ruleVariableDeclaration ) )* otherlv_8= 'Main' ( (lv_Constructor_9_0= ruleNormalStatementBlock ) ) ( (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock ) )* ) )
            // InternalMyGames.g:78:2: (otherlv_0= 'Mainwindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ( (lv_DeclarationSet_7_0= ruleVariableDeclaration ) )* otherlv_8= 'Main' ( (lv_Constructor_9_0= ruleNormalStatementBlock ) ) ( (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock ) )* )
            {
            // InternalMyGames.g:78:2: (otherlv_0= 'Mainwindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ( (lv_DeclarationSet_7_0= ruleVariableDeclaration ) )* otherlv_8= 'Main' ( (lv_Constructor_9_0= ruleNormalStatementBlock ) ) ( (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock ) )* )
            // InternalMyGames.g:79:3: otherlv_0= 'Mainwindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ( (lv_DeclarationSet_7_0= ruleVariableDeclaration ) )* otherlv_8= 'Main' ( (lv_Constructor_9_0= ruleNormalStatementBlock ) ) ( (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock ) )*
            {
            otherlv_0=(Token)match(input,12,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getMinigamesAccess().getMainwindowKeyword_0());
            		
            // InternalMyGames.g:83:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalMyGames.g:84:4: (lv_name_1_0= RULE_ID )
            {
            // InternalMyGames.g:84:4: (lv_name_1_0= RULE_ID )
            // InternalMyGames.g:85:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_name_1_0, grammarAccess.getMinigamesAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMinigamesRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.xtext.game.mygame.MyGames.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_5); 

            			newLeafNode(otherlv_2, grammarAccess.getMinigamesAccess().getLeftParenthesisKeyword_2());
            		
            // InternalMyGames.g:105:3: ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==RULE_ID) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalMyGames.g:106:4: ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )*
                    {
                    // InternalMyGames.g:106:4: ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) )
                    // InternalMyGames.g:107:5: (lv_Formalparameter_3_0= ruleFormalparameterSet )
                    {
                    // InternalMyGames.g:107:5: (lv_Formalparameter_3_0= ruleFormalparameterSet )
                    // InternalMyGames.g:108:6: lv_Formalparameter_3_0= ruleFormalparameterSet
                    {

                    						newCompositeNode(grammarAccess.getMinigamesAccess().getFormalparameterFormalparameterSetParserRuleCall_3_0_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_Formalparameter_3_0=ruleFormalparameterSet();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMinigamesRule());
                    						}
                    						add(
                    							current,
                    							"Formalparameter",
                    							lv_Formalparameter_3_0,
                    							"org.xtext.game.mygame.MyGames.FormalparameterSet");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMyGames.g:125:4: (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )*
                    loop1:
                    do {
                        int alt1=2;
                        int LA1_0 = input.LA(1);

                        if ( (LA1_0==14) ) {
                            alt1=1;
                        }


                        switch (alt1) {
                    	case 1 :
                    	    // InternalMyGames.g:126:5: otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) )
                    	    {
                    	    otherlv_4=(Token)match(input,14,FOLLOW_3); 

                    	    					newLeafNode(otherlv_4, grammarAccess.getMinigamesAccess().getCommaKeyword_3_1_0());
                    	    				
                    	    // InternalMyGames.g:130:5: ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) )
                    	    // InternalMyGames.g:131:6: (lv_Formalparameter_5_0= ruleFormalparameterSet )
                    	    {
                    	    // InternalMyGames.g:131:6: (lv_Formalparameter_5_0= ruleFormalparameterSet )
                    	    // InternalMyGames.g:132:7: lv_Formalparameter_5_0= ruleFormalparameterSet
                    	    {

                    	    							newCompositeNode(grammarAccess.getMinigamesAccess().getFormalparameterFormalparameterSetParserRuleCall_3_1_1_0());
                    	    						
                    	    pushFollow(FOLLOW_6);
                    	    lv_Formalparameter_5_0=ruleFormalparameterSet();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getMinigamesRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"Formalparameter",
                    	    								lv_Formalparameter_5_0,
                    	    								"org.xtext.game.mygame.MyGames.FormalparameterSet");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop1;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_6=(Token)match(input,15,FOLLOW_7); 

            			newLeafNode(otherlv_6, grammarAccess.getMinigamesAccess().getRightParenthesisKeyword_4());
            		
            // InternalMyGames.g:155:3: ( (lv_DeclarationSet_7_0= ruleVariableDeclaration ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==18||LA3_0==26) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalMyGames.g:156:4: (lv_DeclarationSet_7_0= ruleVariableDeclaration )
            	    {
            	    // InternalMyGames.g:156:4: (lv_DeclarationSet_7_0= ruleVariableDeclaration )
            	    // InternalMyGames.g:157:5: lv_DeclarationSet_7_0= ruleVariableDeclaration
            	    {

            	    					newCompositeNode(grammarAccess.getMinigamesAccess().getDeclarationSetVariableDeclarationParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_7);
            	    lv_DeclarationSet_7_0=ruleVariableDeclaration();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getMinigamesRule());
            	    					}
            	    					add(
            	    						current,
            	    						"DeclarationSet",
            	    						lv_DeclarationSet_7_0,
            	    						"org.xtext.game.mygame.MyGames.VariableDeclaration");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            otherlv_8=(Token)match(input,16,FOLLOW_8); 

            			newLeafNode(otherlv_8, grammarAccess.getMinigamesAccess().getMainKeyword_6());
            		
            // InternalMyGames.g:178:3: ( (lv_Constructor_9_0= ruleNormalStatementBlock ) )
            // InternalMyGames.g:179:4: (lv_Constructor_9_0= ruleNormalStatementBlock )
            {
            // InternalMyGames.g:179:4: (lv_Constructor_9_0= ruleNormalStatementBlock )
            // InternalMyGames.g:180:5: lv_Constructor_9_0= ruleNormalStatementBlock
            {

            					newCompositeNode(grammarAccess.getMinigamesAccess().getConstructorNormalStatementBlockParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_9);
            lv_Constructor_9_0=ruleNormalStatementBlock();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMinigamesRule());
            					}
            					set(
            						current,
            						"Constructor",
            						lv_Constructor_9_0,
            						"org.xtext.game.mygame.MyGames.NormalStatementBlock");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyGames.g:197:3: ( (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==28) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalMyGames.g:198:4: (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock )
            	    {
            	    // InternalMyGames.g:198:4: (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock )
            	    // InternalMyGames.g:199:5: lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock
            	    {

            	    					newCompositeNode(grammarAccess.getMinigamesAccess().getKeyPressEventsKeyPressEventsBlockParserRuleCall_8_0());
            	    				
            	    pushFollow(FOLLOW_9);
            	    lv_KeyPressEvents_10_0=ruleKeyPressEventsBlock();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getMinigamesRule());
            	    					}
            	    					add(
            	    						current,
            	    						"KeyPressEvents",
            	    						lv_KeyPressEvents_10_0,
            	    						"org.xtext.game.mygame.MyGames.KeyPressEventsBlock");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMinigames"


    // $ANTLR start "entryRuleVariableDeclaration"
    // InternalMyGames.g:220:1: entryRuleVariableDeclaration returns [EObject current=null] : iv_ruleVariableDeclaration= ruleVariableDeclaration EOF ;
    public final EObject entryRuleVariableDeclaration() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariableDeclaration = null;


        try {
            // InternalMyGames.g:220:60: (iv_ruleVariableDeclaration= ruleVariableDeclaration EOF )
            // InternalMyGames.g:221:2: iv_ruleVariableDeclaration= ruleVariableDeclaration EOF
            {
             newCompositeNode(grammarAccess.getVariableDeclarationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariableDeclaration=ruleVariableDeclaration();

            state._fsp--;

             current =iv_ruleVariableDeclaration; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariableDeclaration"


    // $ANTLR start "ruleVariableDeclaration"
    // InternalMyGames.g:227:1: ruleVariableDeclaration returns [EObject current=null] : ( (this_IntegerDeclaration_0= ruleIntegerDeclaration | this_CharacterDeclaration_1= ruleCharacterDeclaration ) otherlv_2= ';' ) ;
    public final EObject ruleVariableDeclaration() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        EObject this_IntegerDeclaration_0 = null;

        EObject this_CharacterDeclaration_1 = null;



        	enterRule();

        try {
            // InternalMyGames.g:233:2: ( ( (this_IntegerDeclaration_0= ruleIntegerDeclaration | this_CharacterDeclaration_1= ruleCharacterDeclaration ) otherlv_2= ';' ) )
            // InternalMyGames.g:234:2: ( (this_IntegerDeclaration_0= ruleIntegerDeclaration | this_CharacterDeclaration_1= ruleCharacterDeclaration ) otherlv_2= ';' )
            {
            // InternalMyGames.g:234:2: ( (this_IntegerDeclaration_0= ruleIntegerDeclaration | this_CharacterDeclaration_1= ruleCharacterDeclaration ) otherlv_2= ';' )
            // InternalMyGames.g:235:3: (this_IntegerDeclaration_0= ruleIntegerDeclaration | this_CharacterDeclaration_1= ruleCharacterDeclaration ) otherlv_2= ';'
            {
            // InternalMyGames.g:235:3: (this_IntegerDeclaration_0= ruleIntegerDeclaration | this_CharacterDeclaration_1= ruleCharacterDeclaration )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==26) ) {
                alt5=1;
            }
            else if ( (LA5_0==18) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalMyGames.g:236:4: this_IntegerDeclaration_0= ruleIntegerDeclaration
                    {

                    				newCompositeNode(grammarAccess.getVariableDeclarationAccess().getIntegerDeclarationParserRuleCall_0_0());
                    			
                    pushFollow(FOLLOW_10);
                    this_IntegerDeclaration_0=ruleIntegerDeclaration();

                    state._fsp--;


                    				current = this_IntegerDeclaration_0;
                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;
                case 2 :
                    // InternalMyGames.g:245:4: this_CharacterDeclaration_1= ruleCharacterDeclaration
                    {

                    				newCompositeNode(grammarAccess.getVariableDeclarationAccess().getCharacterDeclarationParserRuleCall_0_1());
                    			
                    pushFollow(FOLLOW_10);
                    this_CharacterDeclaration_1=ruleCharacterDeclaration();

                    state._fsp--;


                    				current = this_CharacterDeclaration_1;
                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            otherlv_2=(Token)match(input,17,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getVariableDeclarationAccess().getSemicolonKeyword_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariableDeclaration"


    // $ANTLR start "entryRuleCharacterDeclaration"
    // InternalMyGames.g:262:1: entryRuleCharacterDeclaration returns [EObject current=null] : iv_ruleCharacterDeclaration= ruleCharacterDeclaration EOF ;
    public final EObject entryRuleCharacterDeclaration() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCharacterDeclaration = null;


        try {
            // InternalMyGames.g:262:61: (iv_ruleCharacterDeclaration= ruleCharacterDeclaration EOF )
            // InternalMyGames.g:263:2: iv_ruleCharacterDeclaration= ruleCharacterDeclaration EOF
            {
             newCompositeNode(grammarAccess.getCharacterDeclarationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCharacterDeclaration=ruleCharacterDeclaration();

            state._fsp--;

             current =iv_ruleCharacterDeclaration; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCharacterDeclaration"


    // $ANTLR start "ruleCharacterDeclaration"
    // InternalMyGames.g:269:1: ruleCharacterDeclaration returns [EObject current=null] : (otherlv_0= 'Character' ( (lv_Datatype_1_0= ruleCharacterType ) ) ( (lv_name_2_0= RULE_ID ) ) ( (otherlv_3= '(' ( ( (lv_Formalparameter_4_0= ruleFormalparameterSet ) ) (otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) ) )* )? otherlv_7= ')' ) | ( () otherlv_9= '[' ( (lv_length_10_0= RULE_NUMBER ) ) otherlv_11= ']' ) ) ) ;
    public final EObject ruleCharacterDeclaration() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token lv_length_10_0=null;
        Token otherlv_11=null;
        AntlrDatatypeRuleToken lv_Datatype_1_0 = null;

        EObject lv_Formalparameter_4_0 = null;

        EObject lv_Formalparameter_6_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:275:2: ( (otherlv_0= 'Character' ( (lv_Datatype_1_0= ruleCharacterType ) ) ( (lv_name_2_0= RULE_ID ) ) ( (otherlv_3= '(' ( ( (lv_Formalparameter_4_0= ruleFormalparameterSet ) ) (otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) ) )* )? otherlv_7= ')' ) | ( () otherlv_9= '[' ( (lv_length_10_0= RULE_NUMBER ) ) otherlv_11= ']' ) ) ) )
            // InternalMyGames.g:276:2: (otherlv_0= 'Character' ( (lv_Datatype_1_0= ruleCharacterType ) ) ( (lv_name_2_0= RULE_ID ) ) ( (otherlv_3= '(' ( ( (lv_Formalparameter_4_0= ruleFormalparameterSet ) ) (otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) ) )* )? otherlv_7= ')' ) | ( () otherlv_9= '[' ( (lv_length_10_0= RULE_NUMBER ) ) otherlv_11= ']' ) ) )
            {
            // InternalMyGames.g:276:2: (otherlv_0= 'Character' ( (lv_Datatype_1_0= ruleCharacterType ) ) ( (lv_name_2_0= RULE_ID ) ) ( (otherlv_3= '(' ( ( (lv_Formalparameter_4_0= ruleFormalparameterSet ) ) (otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) ) )* )? otherlv_7= ')' ) | ( () otherlv_9= '[' ( (lv_length_10_0= RULE_NUMBER ) ) otherlv_11= ']' ) ) )
            // InternalMyGames.g:277:3: otherlv_0= 'Character' ( (lv_Datatype_1_0= ruleCharacterType ) ) ( (lv_name_2_0= RULE_ID ) ) ( (otherlv_3= '(' ( ( (lv_Formalparameter_4_0= ruleFormalparameterSet ) ) (otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) ) )* )? otherlv_7= ')' ) | ( () otherlv_9= '[' ( (lv_length_10_0= RULE_NUMBER ) ) otherlv_11= ']' ) )
            {
            otherlv_0=(Token)match(input,18,FOLLOW_11); 

            			newLeafNode(otherlv_0, grammarAccess.getCharacterDeclarationAccess().getCharacterKeyword_0());
            		
            // InternalMyGames.g:281:3: ( (lv_Datatype_1_0= ruleCharacterType ) )
            // InternalMyGames.g:282:4: (lv_Datatype_1_0= ruleCharacterType )
            {
            // InternalMyGames.g:282:4: (lv_Datatype_1_0= ruleCharacterType )
            // InternalMyGames.g:283:5: lv_Datatype_1_0= ruleCharacterType
            {

            					newCompositeNode(grammarAccess.getCharacterDeclarationAccess().getDatatypeCharacterTypeParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_3);
            lv_Datatype_1_0=ruleCharacterType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCharacterDeclarationRule());
            					}
            					set(
            						current,
            						"Datatype",
            						lv_Datatype_1_0,
            						"org.xtext.game.mygame.MyGames.CharacterType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyGames.g:300:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalMyGames.g:301:4: (lv_name_2_0= RULE_ID )
            {
            // InternalMyGames.g:301:4: (lv_name_2_0= RULE_ID )
            // InternalMyGames.g:302:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_12); 

            					newLeafNode(lv_name_2_0, grammarAccess.getCharacterDeclarationAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCharacterDeclarationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.xtext.game.mygame.MyGames.ID");
            				

            }


            }

            // InternalMyGames.g:318:3: ( (otherlv_3= '(' ( ( (lv_Formalparameter_4_0= ruleFormalparameterSet ) ) (otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) ) )* )? otherlv_7= ')' ) | ( () otherlv_9= '[' ( (lv_length_10_0= RULE_NUMBER ) ) otherlv_11= ']' ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==13) ) {
                alt8=1;
            }
            else if ( (LA8_0==19) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalMyGames.g:319:4: (otherlv_3= '(' ( ( (lv_Formalparameter_4_0= ruleFormalparameterSet ) ) (otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) ) )* )? otherlv_7= ')' )
                    {
                    // InternalMyGames.g:319:4: (otherlv_3= '(' ( ( (lv_Formalparameter_4_0= ruleFormalparameterSet ) ) (otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) ) )* )? otherlv_7= ')' )
                    // InternalMyGames.g:320:5: otherlv_3= '(' ( ( (lv_Formalparameter_4_0= ruleFormalparameterSet ) ) (otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) ) )* )? otherlv_7= ')'
                    {
                    otherlv_3=(Token)match(input,13,FOLLOW_5); 

                    					newLeafNode(otherlv_3, grammarAccess.getCharacterDeclarationAccess().getLeftParenthesisKeyword_3_0_0());
                    				
                    // InternalMyGames.g:324:5: ( ( (lv_Formalparameter_4_0= ruleFormalparameterSet ) ) (otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) ) )* )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==RULE_ID) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // InternalMyGames.g:325:6: ( (lv_Formalparameter_4_0= ruleFormalparameterSet ) ) (otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) ) )*
                            {
                            // InternalMyGames.g:325:6: ( (lv_Formalparameter_4_0= ruleFormalparameterSet ) )
                            // InternalMyGames.g:326:7: (lv_Formalparameter_4_0= ruleFormalparameterSet )
                            {
                            // InternalMyGames.g:326:7: (lv_Formalparameter_4_0= ruleFormalparameterSet )
                            // InternalMyGames.g:327:8: lv_Formalparameter_4_0= ruleFormalparameterSet
                            {

                            								newCompositeNode(grammarAccess.getCharacterDeclarationAccess().getFormalparameterFormalparameterSetParserRuleCall_3_0_1_0_0());
                            							
                            pushFollow(FOLLOW_6);
                            lv_Formalparameter_4_0=ruleFormalparameterSet();

                            state._fsp--;


                            								if (current==null) {
                            									current = createModelElementForParent(grammarAccess.getCharacterDeclarationRule());
                            								}
                            								add(
                            									current,
                            									"Formalparameter",
                            									lv_Formalparameter_4_0,
                            									"org.xtext.game.mygame.MyGames.FormalparameterSet");
                            								afterParserOrEnumRuleCall();
                            							

                            }


                            }

                            // InternalMyGames.g:344:6: (otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) ) )*
                            loop6:
                            do {
                                int alt6=2;
                                int LA6_0 = input.LA(1);

                                if ( (LA6_0==14) ) {
                                    alt6=1;
                                }


                                switch (alt6) {
                            	case 1 :
                            	    // InternalMyGames.g:345:7: otherlv_5= ',' ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) )
                            	    {
                            	    otherlv_5=(Token)match(input,14,FOLLOW_3); 

                            	    							newLeafNode(otherlv_5, grammarAccess.getCharacterDeclarationAccess().getCommaKeyword_3_0_1_1_0());
                            	    						
                            	    // InternalMyGames.g:349:7: ( (lv_Formalparameter_6_0= ruleFormalparameterSet ) )
                            	    // InternalMyGames.g:350:8: (lv_Formalparameter_6_0= ruleFormalparameterSet )
                            	    {
                            	    // InternalMyGames.g:350:8: (lv_Formalparameter_6_0= ruleFormalparameterSet )
                            	    // InternalMyGames.g:351:9: lv_Formalparameter_6_0= ruleFormalparameterSet
                            	    {

                            	    									newCompositeNode(grammarAccess.getCharacterDeclarationAccess().getFormalparameterFormalparameterSetParserRuleCall_3_0_1_1_1_0());
                            	    								
                            	    pushFollow(FOLLOW_6);
                            	    lv_Formalparameter_6_0=ruleFormalparameterSet();

                            	    state._fsp--;


                            	    									if (current==null) {
                            	    										current = createModelElementForParent(grammarAccess.getCharacterDeclarationRule());
                            	    									}
                            	    									add(
                            	    										current,
                            	    										"Formalparameter",
                            	    										lv_Formalparameter_6_0,
                            	    										"org.xtext.game.mygame.MyGames.FormalparameterSet");
                            	    									afterParserOrEnumRuleCall();
                            	    								

                            	    }


                            	    }


                            	    }
                            	    break;

                            	default :
                            	    break loop6;
                                }
                            } while (true);


                            }
                            break;

                    }

                    otherlv_7=(Token)match(input,15,FOLLOW_2); 

                    					newLeafNode(otherlv_7, grammarAccess.getCharacterDeclarationAccess().getRightParenthesisKeyword_3_0_2());
                    				

                    }


                    }
                    break;
                case 2 :
                    // InternalMyGames.g:376:4: ( () otherlv_9= '[' ( (lv_length_10_0= RULE_NUMBER ) ) otherlv_11= ']' )
                    {
                    // InternalMyGames.g:376:4: ( () otherlv_9= '[' ( (lv_length_10_0= RULE_NUMBER ) ) otherlv_11= ']' )
                    // InternalMyGames.g:377:5: () otherlv_9= '[' ( (lv_length_10_0= RULE_NUMBER ) ) otherlv_11= ']'
                    {
                    // InternalMyGames.g:377:5: ()
                    // InternalMyGames.g:378:6: 
                    {

                    						current = forceCreateModelElementAndSet(
                    							grammarAccess.getCharacterDeclarationAccess().getArrayDeclarationVariableAction_3_1_0(),
                    							current);
                    					

                    }

                    otherlv_9=(Token)match(input,19,FOLLOW_13); 

                    					newLeafNode(otherlv_9, grammarAccess.getCharacterDeclarationAccess().getLeftSquareBracketKeyword_3_1_1());
                    				
                    // InternalMyGames.g:388:5: ( (lv_length_10_0= RULE_NUMBER ) )
                    // InternalMyGames.g:389:6: (lv_length_10_0= RULE_NUMBER )
                    {
                    // InternalMyGames.g:389:6: (lv_length_10_0= RULE_NUMBER )
                    // InternalMyGames.g:390:7: lv_length_10_0= RULE_NUMBER
                    {
                    lv_length_10_0=(Token)match(input,RULE_NUMBER,FOLLOW_14); 

                    							newLeafNode(lv_length_10_0, grammarAccess.getCharacterDeclarationAccess().getLengthNUMBERTerminalRuleCall_3_1_2_0());
                    						

                    							if (current==null) {
                    								current = createModelElement(grammarAccess.getCharacterDeclarationRule());
                    							}
                    							setWithLastConsumed(
                    								current,
                    								"length",
                    								lv_length_10_0,
                    								"org.xtext.game.mygame.MyGames.NUMBER");
                    						

                    }


                    }

                    otherlv_11=(Token)match(input,20,FOLLOW_2); 

                    					newLeafNode(otherlv_11, grammarAccess.getCharacterDeclarationAccess().getRightSquareBracketKeyword_3_1_3());
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCharacterDeclaration"


    // $ANTLR start "entryRuleCharacterType"
    // InternalMyGames.g:416:1: entryRuleCharacterType returns [String current=null] : iv_ruleCharacterType= ruleCharacterType EOF ;
    public final String entryRuleCharacterType() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleCharacterType = null;


        try {
            // InternalMyGames.g:416:53: (iv_ruleCharacterType= ruleCharacterType EOF )
            // InternalMyGames.g:417:2: iv_ruleCharacterType= ruleCharacterType EOF
            {
             newCompositeNode(grammarAccess.getCharacterTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCharacterType=ruleCharacterType();

            state._fsp--;

             current =iv_ruleCharacterType.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCharacterType"


    // $ANTLR start "ruleCharacterType"
    // InternalMyGames.g:423:1: ruleCharacterType returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'Player' | kw= 'Obstacle' | kw= 'GameProps' | kw= 'Destination' ) ;
    public final AntlrDatatypeRuleToken ruleCharacterType() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyGames.g:429:2: ( (kw= 'Player' | kw= 'Obstacle' | kw= 'GameProps' | kw= 'Destination' ) )
            // InternalMyGames.g:430:2: (kw= 'Player' | kw= 'Obstacle' | kw= 'GameProps' | kw= 'Destination' )
            {
            // InternalMyGames.g:430:2: (kw= 'Player' | kw= 'Obstacle' | kw= 'GameProps' | kw= 'Destination' )
            int alt9=4;
            switch ( input.LA(1) ) {
            case 21:
                {
                alt9=1;
                }
                break;
            case 22:
                {
                alt9=2;
                }
                break;
            case 23:
                {
                alt9=3;
                }
                break;
            case 24:
                {
                alt9=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalMyGames.g:431:3: kw= 'Player'
                    {
                    kw=(Token)match(input,21,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getCharacterTypeAccess().getPlayerKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMyGames.g:437:3: kw= 'Obstacle'
                    {
                    kw=(Token)match(input,22,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getCharacterTypeAccess().getObstacleKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalMyGames.g:443:3: kw= 'GameProps'
                    {
                    kw=(Token)match(input,23,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getCharacterTypeAccess().getGamePropsKeyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalMyGames.g:449:3: kw= 'Destination'
                    {
                    kw=(Token)match(input,24,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getCharacterTypeAccess().getDestinationKeyword_3());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCharacterType"


    // $ANTLR start "entryRuleFormalparameterSet"
    // InternalMyGames.g:458:1: entryRuleFormalparameterSet returns [EObject current=null] : iv_ruleFormalparameterSet= ruleFormalparameterSet EOF ;
    public final EObject entryRuleFormalparameterSet() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFormalparameterSet = null;


        try {
            // InternalMyGames.g:458:59: (iv_ruleFormalparameterSet= ruleFormalparameterSet EOF )
            // InternalMyGames.g:459:2: iv_ruleFormalparameterSet= ruleFormalparameterSet EOF
            {
             newCompositeNode(grammarAccess.getFormalparameterSetRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFormalparameterSet=ruleFormalparameterSet();

            state._fsp--;

             current =iv_ruleFormalparameterSet; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFormalparameterSet"


    // $ANTLR start "ruleFormalparameterSet"
    // InternalMyGames.g:465:1: ruleFormalparameterSet returns [EObject current=null] : ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= ruleExpression ) ) ) ;
    public final EObject ruleFormalparameterSet() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        EObject lv_value_2_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:471:2: ( ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= ruleExpression ) ) ) )
            // InternalMyGames.g:472:2: ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= ruleExpression ) ) )
            {
            // InternalMyGames.g:472:2: ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= ruleExpression ) ) )
            // InternalMyGames.g:473:3: ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= ruleExpression ) )
            {
            // InternalMyGames.g:473:3: ( (lv_name_0_0= RULE_ID ) )
            // InternalMyGames.g:474:4: (lv_name_0_0= RULE_ID )
            {
            // InternalMyGames.g:474:4: (lv_name_0_0= RULE_ID )
            // InternalMyGames.g:475:5: lv_name_0_0= RULE_ID
            {
            lv_name_0_0=(Token)match(input,RULE_ID,FOLLOW_15); 

            					newLeafNode(lv_name_0_0, grammarAccess.getFormalparameterSetAccess().getNameIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFormalparameterSetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_0_0,
            						"org.xtext.game.mygame.MyGames.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,25,FOLLOW_16); 

            			newLeafNode(otherlv_1, grammarAccess.getFormalparameterSetAccess().getEqualsSignKeyword_1());
            		
            // InternalMyGames.g:495:3: ( (lv_value_2_0= ruleExpression ) )
            // InternalMyGames.g:496:4: (lv_value_2_0= ruleExpression )
            {
            // InternalMyGames.g:496:4: (lv_value_2_0= ruleExpression )
            // InternalMyGames.g:497:5: lv_value_2_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getFormalparameterSetAccess().getValueExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_value_2_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFormalparameterSetRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_2_0,
            						"org.xtext.game.mygame.MyGames.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFormalparameterSet"


    // $ANTLR start "entryRuleIntegerDeclaration"
    // InternalMyGames.g:518:1: entryRuleIntegerDeclaration returns [EObject current=null] : iv_ruleIntegerDeclaration= ruleIntegerDeclaration EOF ;
    public final EObject entryRuleIntegerDeclaration() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIntegerDeclaration = null;


        try {
            // InternalMyGames.g:518:59: (iv_ruleIntegerDeclaration= ruleIntegerDeclaration EOF )
            // InternalMyGames.g:519:2: iv_ruleIntegerDeclaration= ruleIntegerDeclaration EOF
            {
             newCompositeNode(grammarAccess.getIntegerDeclarationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIntegerDeclaration=ruleIntegerDeclaration();

            state._fsp--;

             current =iv_ruleIntegerDeclaration; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIntegerDeclaration"


    // $ANTLR start "ruleIntegerDeclaration"
    // InternalMyGames.g:525:1: ruleIntegerDeclaration returns [EObject current=null] : (otherlv_0= 'Var' ( (lv_Datatype_1_0= 'int' ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_init_3_0= ruleVariableInitiation ) )? ) ;
    public final EObject ruleIntegerDeclaration() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_Datatype_1_0=null;
        Token lv_name_2_0=null;
        EObject lv_init_3_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:531:2: ( (otherlv_0= 'Var' ( (lv_Datatype_1_0= 'int' ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_init_3_0= ruleVariableInitiation ) )? ) )
            // InternalMyGames.g:532:2: (otherlv_0= 'Var' ( (lv_Datatype_1_0= 'int' ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_init_3_0= ruleVariableInitiation ) )? )
            {
            // InternalMyGames.g:532:2: (otherlv_0= 'Var' ( (lv_Datatype_1_0= 'int' ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_init_3_0= ruleVariableInitiation ) )? )
            // InternalMyGames.g:533:3: otherlv_0= 'Var' ( (lv_Datatype_1_0= 'int' ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_init_3_0= ruleVariableInitiation ) )?
            {
            otherlv_0=(Token)match(input,26,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getIntegerDeclarationAccess().getVarKeyword_0());
            		
            // InternalMyGames.g:537:3: ( (lv_Datatype_1_0= 'int' ) )
            // InternalMyGames.g:538:4: (lv_Datatype_1_0= 'int' )
            {
            // InternalMyGames.g:538:4: (lv_Datatype_1_0= 'int' )
            // InternalMyGames.g:539:5: lv_Datatype_1_0= 'int'
            {
            lv_Datatype_1_0=(Token)match(input,27,FOLLOW_3); 

            					newLeafNode(lv_Datatype_1_0, grammarAccess.getIntegerDeclarationAccess().getDatatypeIntKeyword_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getIntegerDeclarationRule());
            					}
            					setWithLastConsumed(current, "Datatype", lv_Datatype_1_0, "int");
            				

            }


            }

            // InternalMyGames.g:551:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalMyGames.g:552:4: (lv_name_2_0= RULE_ID )
            {
            // InternalMyGames.g:552:4: (lv_name_2_0= RULE_ID )
            // InternalMyGames.g:553:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_18); 

            					newLeafNode(lv_name_2_0, grammarAccess.getIntegerDeclarationAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getIntegerDeclarationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.xtext.game.mygame.MyGames.ID");
            				

            }


            }

            // InternalMyGames.g:569:3: ( (lv_init_3_0= ruleVariableInitiation ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==25) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalMyGames.g:570:4: (lv_init_3_0= ruleVariableInitiation )
                    {
                    // InternalMyGames.g:570:4: (lv_init_3_0= ruleVariableInitiation )
                    // InternalMyGames.g:571:5: lv_init_3_0= ruleVariableInitiation
                    {

                    					newCompositeNode(grammarAccess.getIntegerDeclarationAccess().getInitVariableInitiationParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_init_3_0=ruleVariableInitiation();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getIntegerDeclarationRule());
                    					}
                    					set(
                    						current,
                    						"init",
                    						lv_init_3_0,
                    						"org.xtext.game.mygame.MyGames.VariableInitiation");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIntegerDeclaration"


    // $ANTLR start "entryRuleVariableInitiation"
    // InternalMyGames.g:592:1: entryRuleVariableInitiation returns [EObject current=null] : iv_ruleVariableInitiation= ruleVariableInitiation EOF ;
    public final EObject entryRuleVariableInitiation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariableInitiation = null;


        try {
            // InternalMyGames.g:592:59: (iv_ruleVariableInitiation= ruleVariableInitiation EOF )
            // InternalMyGames.g:593:2: iv_ruleVariableInitiation= ruleVariableInitiation EOF
            {
             newCompositeNode(grammarAccess.getVariableInitiationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariableInitiation=ruleVariableInitiation();

            state._fsp--;

             current =iv_ruleVariableInitiation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariableInitiation"


    // $ANTLR start "ruleVariableInitiation"
    // InternalMyGames.g:599:1: ruleVariableInitiation returns [EObject current=null] : (otherlv_0= '=' this_Expression_1= ruleExpression ) ;
    public final EObject ruleVariableInitiation() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_Expression_1 = null;



        	enterRule();

        try {
            // InternalMyGames.g:605:2: ( (otherlv_0= '=' this_Expression_1= ruleExpression ) )
            // InternalMyGames.g:606:2: (otherlv_0= '=' this_Expression_1= ruleExpression )
            {
            // InternalMyGames.g:606:2: (otherlv_0= '=' this_Expression_1= ruleExpression )
            // InternalMyGames.g:607:3: otherlv_0= '=' this_Expression_1= ruleExpression
            {
            otherlv_0=(Token)match(input,25,FOLLOW_16); 

            			newLeafNode(otherlv_0, grammarAccess.getVariableInitiationAccess().getEqualsSignKeyword_0());
            		

            			newCompositeNode(grammarAccess.getVariableInitiationAccess().getExpressionParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_Expression_1=ruleExpression();

            state._fsp--;


            			current = this_Expression_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariableInitiation"


    // $ANTLR start "entryRuleKeyPressEventsBlock"
    // InternalMyGames.g:623:1: entryRuleKeyPressEventsBlock returns [EObject current=null] : iv_ruleKeyPressEventsBlock= ruleKeyPressEventsBlock EOF ;
    public final EObject entryRuleKeyPressEventsBlock() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleKeyPressEventsBlock = null;


        try {
            // InternalMyGames.g:623:60: (iv_ruleKeyPressEventsBlock= ruleKeyPressEventsBlock EOF )
            // InternalMyGames.g:624:2: iv_ruleKeyPressEventsBlock= ruleKeyPressEventsBlock EOF
            {
             newCompositeNode(grammarAccess.getKeyPressEventsBlockRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleKeyPressEventsBlock=ruleKeyPressEventsBlock();

            state._fsp--;

             current =iv_ruleKeyPressEventsBlock; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleKeyPressEventsBlock"


    // $ANTLR start "ruleKeyPressEventsBlock"
    // InternalMyGames.g:630:1: ruleKeyPressEventsBlock returns [EObject current=null] : (otherlv_0= 'Trigger' ( (lv_keyschoice_1_0= ruleKeys ) ) ( (lv_triggerstatements_2_0= ruleNormalStatementBlock ) ) ) ;
    public final EObject ruleKeyPressEventsBlock() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_keyschoice_1_0 = null;

        EObject lv_triggerstatements_2_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:636:2: ( (otherlv_0= 'Trigger' ( (lv_keyschoice_1_0= ruleKeys ) ) ( (lv_triggerstatements_2_0= ruleNormalStatementBlock ) ) ) )
            // InternalMyGames.g:637:2: (otherlv_0= 'Trigger' ( (lv_keyschoice_1_0= ruleKeys ) ) ( (lv_triggerstatements_2_0= ruleNormalStatementBlock ) ) )
            {
            // InternalMyGames.g:637:2: (otherlv_0= 'Trigger' ( (lv_keyschoice_1_0= ruleKeys ) ) ( (lv_triggerstatements_2_0= ruleNormalStatementBlock ) ) )
            // InternalMyGames.g:638:3: otherlv_0= 'Trigger' ( (lv_keyschoice_1_0= ruleKeys ) ) ( (lv_triggerstatements_2_0= ruleNormalStatementBlock ) )
            {
            otherlv_0=(Token)match(input,28,FOLLOW_19); 

            			newLeafNode(otherlv_0, grammarAccess.getKeyPressEventsBlockAccess().getTriggerKeyword_0());
            		
            // InternalMyGames.g:642:3: ( (lv_keyschoice_1_0= ruleKeys ) )
            // InternalMyGames.g:643:4: (lv_keyschoice_1_0= ruleKeys )
            {
            // InternalMyGames.g:643:4: (lv_keyschoice_1_0= ruleKeys )
            // InternalMyGames.g:644:5: lv_keyschoice_1_0= ruleKeys
            {

            					newCompositeNode(grammarAccess.getKeyPressEventsBlockAccess().getKeyschoiceKeysParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_8);
            lv_keyschoice_1_0=ruleKeys();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getKeyPressEventsBlockRule());
            					}
            					set(
            						current,
            						"keyschoice",
            						lv_keyschoice_1_0,
            						"org.xtext.game.mygame.MyGames.Keys");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyGames.g:661:3: ( (lv_triggerstatements_2_0= ruleNormalStatementBlock ) )
            // InternalMyGames.g:662:4: (lv_triggerstatements_2_0= ruleNormalStatementBlock )
            {
            // InternalMyGames.g:662:4: (lv_triggerstatements_2_0= ruleNormalStatementBlock )
            // InternalMyGames.g:663:5: lv_triggerstatements_2_0= ruleNormalStatementBlock
            {

            					newCompositeNode(grammarAccess.getKeyPressEventsBlockAccess().getTriggerstatementsNormalStatementBlockParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_triggerstatements_2_0=ruleNormalStatementBlock();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getKeyPressEventsBlockRule());
            					}
            					set(
            						current,
            						"triggerstatements",
            						lv_triggerstatements_2_0,
            						"org.xtext.game.mygame.MyGames.NormalStatementBlock");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleKeyPressEventsBlock"


    // $ANTLR start "entryRuleKeys"
    // InternalMyGames.g:684:1: entryRuleKeys returns [String current=null] : iv_ruleKeys= ruleKeys EOF ;
    public final String entryRuleKeys() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleKeys = null;


        try {
            // InternalMyGames.g:684:44: (iv_ruleKeys= ruleKeys EOF )
            // InternalMyGames.g:685:2: iv_ruleKeys= ruleKeys EOF
            {
             newCompositeNode(grammarAccess.getKeysRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleKeys=ruleKeys();

            state._fsp--;

             current =iv_ruleKeys.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleKeys"


    // $ANTLR start "ruleKeys"
    // InternalMyGames.g:691:1: ruleKeys returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'UP' | kw= 'DOWN' | kw= 'LEFT' | kw= 'RIGHT' ) ;
    public final AntlrDatatypeRuleToken ruleKeys() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyGames.g:697:2: ( (kw= 'UP' | kw= 'DOWN' | kw= 'LEFT' | kw= 'RIGHT' ) )
            // InternalMyGames.g:698:2: (kw= 'UP' | kw= 'DOWN' | kw= 'LEFT' | kw= 'RIGHT' )
            {
            // InternalMyGames.g:698:2: (kw= 'UP' | kw= 'DOWN' | kw= 'LEFT' | kw= 'RIGHT' )
            int alt11=4;
            switch ( input.LA(1) ) {
            case 29:
                {
                alt11=1;
                }
                break;
            case 30:
                {
                alt11=2;
                }
                break;
            case 31:
                {
                alt11=3;
                }
                break;
            case 32:
                {
                alt11=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // InternalMyGames.g:699:3: kw= 'UP'
                    {
                    kw=(Token)match(input,29,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getKeysAccess().getUPKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMyGames.g:705:3: kw= 'DOWN'
                    {
                    kw=(Token)match(input,30,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getKeysAccess().getDOWNKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalMyGames.g:711:3: kw= 'LEFT'
                    {
                    kw=(Token)match(input,31,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getKeysAccess().getLEFTKeyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalMyGames.g:717:3: kw= 'RIGHT'
                    {
                    kw=(Token)match(input,32,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getKeysAccess().getRIGHTKeyword_3());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleKeys"


    // $ANTLR start "entryRuleNormalStatementBlock"
    // InternalMyGames.g:726:1: entryRuleNormalStatementBlock returns [EObject current=null] : iv_ruleNormalStatementBlock= ruleNormalStatementBlock EOF ;
    public final EObject entryRuleNormalStatementBlock() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNormalStatementBlock = null;


        try {
            // InternalMyGames.g:726:61: (iv_ruleNormalStatementBlock= ruleNormalStatementBlock EOF )
            // InternalMyGames.g:727:2: iv_ruleNormalStatementBlock= ruleNormalStatementBlock EOF
            {
             newCompositeNode(grammarAccess.getNormalStatementBlockRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNormalStatementBlock=ruleNormalStatementBlock();

            state._fsp--;

             current =iv_ruleNormalStatementBlock; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNormalStatementBlock"


    // $ANTLR start "ruleNormalStatementBlock"
    // InternalMyGames.g:733:1: ruleNormalStatementBlock returns [EObject current=null] : ( () otherlv_1= '{' ( (lv_normalstatements_2_0= ruleNormalStatement ) )* otherlv_3= '}' ) ;
    public final EObject ruleNormalStatementBlock() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_normalstatements_2_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:739:2: ( ( () otherlv_1= '{' ( (lv_normalstatements_2_0= ruleNormalStatement ) )* otherlv_3= '}' ) )
            // InternalMyGames.g:740:2: ( () otherlv_1= '{' ( (lv_normalstatements_2_0= ruleNormalStatement ) )* otherlv_3= '}' )
            {
            // InternalMyGames.g:740:2: ( () otherlv_1= '{' ( (lv_normalstatements_2_0= ruleNormalStatement ) )* otherlv_3= '}' )
            // InternalMyGames.g:741:3: () otherlv_1= '{' ( (lv_normalstatements_2_0= ruleNormalStatement ) )* otherlv_3= '}'
            {
            // InternalMyGames.g:741:3: ()
            // InternalMyGames.g:742:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getNormalStatementBlockAccess().getNormalStatementBlockAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,33,FOLLOW_20); 

            			newLeafNode(otherlv_1, grammarAccess.getNormalStatementBlockAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalMyGames.g:752:3: ( (lv_normalstatements_2_0= ruleNormalStatement ) )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==RULE_ID||LA12_0==36||LA12_0==38) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalMyGames.g:753:4: (lv_normalstatements_2_0= ruleNormalStatement )
            	    {
            	    // InternalMyGames.g:753:4: (lv_normalstatements_2_0= ruleNormalStatement )
            	    // InternalMyGames.g:754:5: lv_normalstatements_2_0= ruleNormalStatement
            	    {

            	    					newCompositeNode(grammarAccess.getNormalStatementBlockAccess().getNormalstatementsNormalStatementParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_20);
            	    lv_normalstatements_2_0=ruleNormalStatement();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getNormalStatementBlockRule());
            	    					}
            	    					add(
            	    						current,
            	    						"normalstatements",
            	    						lv_normalstatements_2_0,
            	    						"org.xtext.game.mygame.MyGames.NormalStatement");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

            otherlv_3=(Token)match(input,34,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getNormalStatementBlockAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNormalStatementBlock"


    // $ANTLR start "entryRuleNormalStatement"
    // InternalMyGames.g:779:1: entryRuleNormalStatement returns [EObject current=null] : iv_ruleNormalStatement= ruleNormalStatement EOF ;
    public final EObject entryRuleNormalStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNormalStatement = null;


        try {
            // InternalMyGames.g:779:56: (iv_ruleNormalStatement= ruleNormalStatement EOF )
            // InternalMyGames.g:780:2: iv_ruleNormalStatement= ruleNormalStatement EOF
            {
             newCompositeNode(grammarAccess.getNormalStatementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNormalStatement=ruleNormalStatement();

            state._fsp--;

             current =iv_ruleNormalStatement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNormalStatement"


    // $ANTLR start "ruleNormalStatement"
    // InternalMyGames.g:786:1: ruleNormalStatement returns [EObject current=null] : (this_IfStatement_0= ruleIfStatement | this_ForStatement_1= ruleForStatement | (this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';' ) ) ;
    public final EObject ruleNormalStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_3=null;
        EObject this_IfStatement_0 = null;

        EObject this_ForStatement_1 = null;

        EObject this_AssignmentStatement_2 = null;



        	enterRule();

        try {
            // InternalMyGames.g:792:2: ( (this_IfStatement_0= ruleIfStatement | this_ForStatement_1= ruleForStatement | (this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';' ) ) )
            // InternalMyGames.g:793:2: (this_IfStatement_0= ruleIfStatement | this_ForStatement_1= ruleForStatement | (this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';' ) )
            {
            // InternalMyGames.g:793:2: (this_IfStatement_0= ruleIfStatement | this_ForStatement_1= ruleForStatement | (this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';' ) )
            int alt13=3;
            switch ( input.LA(1) ) {
            case 36:
                {
                alt13=1;
                }
                break;
            case 38:
                {
                alt13=2;
                }
                break;
            case RULE_ID:
                {
                alt13=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }

            switch (alt13) {
                case 1 :
                    // InternalMyGames.g:794:3: this_IfStatement_0= ruleIfStatement
                    {

                    			newCompositeNode(grammarAccess.getNormalStatementAccess().getIfStatementParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_IfStatement_0=ruleIfStatement();

                    state._fsp--;


                    			current = this_IfStatement_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMyGames.g:803:3: this_ForStatement_1= ruleForStatement
                    {

                    			newCompositeNode(grammarAccess.getNormalStatementAccess().getForStatementParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_ForStatement_1=ruleForStatement();

                    state._fsp--;


                    			current = this_ForStatement_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMyGames.g:812:3: (this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';' )
                    {
                    // InternalMyGames.g:812:3: (this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';' )
                    // InternalMyGames.g:813:4: this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';'
                    {

                    				newCompositeNode(grammarAccess.getNormalStatementAccess().getAssignmentStatementParserRuleCall_2_0());
                    			
                    pushFollow(FOLLOW_10);
                    this_AssignmentStatement_2=ruleAssignmentStatement();

                    state._fsp--;


                    				current = this_AssignmentStatement_2;
                    				afterParserOrEnumRuleCall();
                    			
                    otherlv_3=(Token)match(input,17,FOLLOW_2); 

                    				newLeafNode(otherlv_3, grammarAccess.getNormalStatementAccess().getSemicolonKeyword_2_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNormalStatement"


    // $ANTLR start "entryRuleAssignmentStatement"
    // InternalMyGames.g:830:1: entryRuleAssignmentStatement returns [EObject current=null] : iv_ruleAssignmentStatement= ruleAssignmentStatement EOF ;
    public final EObject entryRuleAssignmentStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAssignmentStatement = null;


        try {
            // InternalMyGames.g:830:60: (iv_ruleAssignmentStatement= ruleAssignmentStatement EOF )
            // InternalMyGames.g:831:2: iv_ruleAssignmentStatement= ruleAssignmentStatement EOF
            {
             newCompositeNode(grammarAccess.getAssignmentStatementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAssignmentStatement=ruleAssignmentStatement();

            state._fsp--;

             current =iv_ruleAssignmentStatement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAssignmentStatement"


    // $ANTLR start "ruleAssignmentStatement"
    // InternalMyGames.g:837:1: ruleAssignmentStatement returns [EObject current=null] : ( ( (lv_variable_0_0= ruleVaraible ) ) otherlv_1= '=' ( (lv_expression_2_0= ruleExpression ) ) ) ;
    public final EObject ruleAssignmentStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_variable_0_0 = null;

        EObject lv_expression_2_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:843:2: ( ( ( (lv_variable_0_0= ruleVaraible ) ) otherlv_1= '=' ( (lv_expression_2_0= ruleExpression ) ) ) )
            // InternalMyGames.g:844:2: ( ( (lv_variable_0_0= ruleVaraible ) ) otherlv_1= '=' ( (lv_expression_2_0= ruleExpression ) ) )
            {
            // InternalMyGames.g:844:2: ( ( (lv_variable_0_0= ruleVaraible ) ) otherlv_1= '=' ( (lv_expression_2_0= ruleExpression ) ) )
            // InternalMyGames.g:845:3: ( (lv_variable_0_0= ruleVaraible ) ) otherlv_1= '=' ( (lv_expression_2_0= ruleExpression ) )
            {
            // InternalMyGames.g:845:3: ( (lv_variable_0_0= ruleVaraible ) )
            // InternalMyGames.g:846:4: (lv_variable_0_0= ruleVaraible )
            {
            // InternalMyGames.g:846:4: (lv_variable_0_0= ruleVaraible )
            // InternalMyGames.g:847:5: lv_variable_0_0= ruleVaraible
            {

            					newCompositeNode(grammarAccess.getAssignmentStatementAccess().getVariableVaraibleParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_15);
            lv_variable_0_0=ruleVaraible();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAssignmentStatementRule());
            					}
            					set(
            						current,
            						"variable",
            						lv_variable_0_0,
            						"org.xtext.game.mygame.MyGames.Varaible");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_1=(Token)match(input,25,FOLLOW_16); 

            			newLeafNode(otherlv_1, grammarAccess.getAssignmentStatementAccess().getEqualsSignKeyword_1());
            		
            // InternalMyGames.g:868:3: ( (lv_expression_2_0= ruleExpression ) )
            // InternalMyGames.g:869:4: (lv_expression_2_0= ruleExpression )
            {
            // InternalMyGames.g:869:4: (lv_expression_2_0= ruleExpression )
            // InternalMyGames.g:870:5: lv_expression_2_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getAssignmentStatementAccess().getExpressionExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_expression_2_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAssignmentStatementRule());
            					}
            					set(
            						current,
            						"expression",
            						lv_expression_2_0,
            						"org.xtext.game.mygame.MyGames.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAssignmentStatement"


    // $ANTLR start "entryRuleVaraible"
    // InternalMyGames.g:891:1: entryRuleVaraible returns [EObject current=null] : iv_ruleVaraible= ruleVaraible EOF ;
    public final EObject entryRuleVaraible() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVaraible = null;


        try {
            // InternalMyGames.g:891:49: (iv_ruleVaraible= ruleVaraible EOF )
            // InternalMyGames.g:892:2: iv_ruleVaraible= ruleVaraible EOF
            {
             newCompositeNode(grammarAccess.getVaraibleRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVaraible=ruleVaraible();

            state._fsp--;

             current =iv_ruleVaraible; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVaraible"


    // $ANTLR start "ruleVaraible"
    // InternalMyGames.g:898:1: ruleVaraible returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) ( () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']' )? ( () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) ) )? ) ;
    public final EObject ruleVaraible() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token lv_attributes_7_0=null;
        EObject lv_index_3_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:904:2: ( ( ( (otherlv_0= RULE_ID ) ) ( () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']' )? ( () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) ) )? ) )
            // InternalMyGames.g:905:2: ( ( (otherlv_0= RULE_ID ) ) ( () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']' )? ( () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) ) )? )
            {
            // InternalMyGames.g:905:2: ( ( (otherlv_0= RULE_ID ) ) ( () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']' )? ( () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) ) )? )
            // InternalMyGames.g:906:3: ( (otherlv_0= RULE_ID ) ) ( () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']' )? ( () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) ) )?
            {
            // InternalMyGames.g:906:3: ( (otherlv_0= RULE_ID ) )
            // InternalMyGames.g:907:4: (otherlv_0= RULE_ID )
            {
            // InternalMyGames.g:907:4: (otherlv_0= RULE_ID )
            // InternalMyGames.g:908:5: otherlv_0= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVaraibleRule());
            					}
            				
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_21); 

            					newLeafNode(otherlv_0, grammarAccess.getVaraibleAccess().getIdAllDeclarationsCrossReference_0_0());
            				

            }


            }

            // InternalMyGames.g:919:3: ( () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']' )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==19) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalMyGames.g:920:4: () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']'
                    {
                    // InternalMyGames.g:920:4: ()
                    // InternalMyGames.g:921:5: 
                    {

                    					current = forceCreateModelElementAndSet(
                    						grammarAccess.getVaraibleAccess().getCharacterMemberVariableAction_1_0(),
                    						current);
                    				

                    }

                    otherlv_2=(Token)match(input,19,FOLLOW_16); 

                    				newLeafNode(otherlv_2, grammarAccess.getVaraibleAccess().getLeftSquareBracketKeyword_1_1());
                    			
                    // InternalMyGames.g:931:4: ( (lv_index_3_0= ruleExpression ) )
                    // InternalMyGames.g:932:5: (lv_index_3_0= ruleExpression )
                    {
                    // InternalMyGames.g:932:5: (lv_index_3_0= ruleExpression )
                    // InternalMyGames.g:933:6: lv_index_3_0= ruleExpression
                    {

                    						newCompositeNode(grammarAccess.getVaraibleAccess().getIndexExpressionParserRuleCall_1_2_0());
                    					
                    pushFollow(FOLLOW_14);
                    lv_index_3_0=ruleExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getVaraibleRule());
                    						}
                    						set(
                    							current,
                    							"index",
                    							lv_index_3_0,
                    							"org.xtext.game.mygame.MyGames.Expression");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    otherlv_4=(Token)match(input,20,FOLLOW_22); 

                    				newLeafNode(otherlv_4, grammarAccess.getVaraibleAccess().getRightSquareBracketKeyword_1_3());
                    			

                    }
                    break;

            }

            // InternalMyGames.g:955:3: ( () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==35) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalMyGames.g:956:4: () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) )
                    {
                    // InternalMyGames.g:956:4: ()
                    // InternalMyGames.g:957:5: 
                    {

                    					current = forceCreateModelElementAndSet(
                    						grammarAccess.getVaraibleAccess().getCharacterAttributeVariableAction_2_0(),
                    						current);
                    				

                    }

                    otherlv_6=(Token)match(input,35,FOLLOW_3); 

                    				newLeafNode(otherlv_6, grammarAccess.getVaraibleAccess().getFullStopKeyword_2_1());
                    			
                    // InternalMyGames.g:967:4: ( (lv_attributes_7_0= RULE_ID ) )
                    // InternalMyGames.g:968:5: (lv_attributes_7_0= RULE_ID )
                    {
                    // InternalMyGames.g:968:5: (lv_attributes_7_0= RULE_ID )
                    // InternalMyGames.g:969:6: lv_attributes_7_0= RULE_ID
                    {
                    lv_attributes_7_0=(Token)match(input,RULE_ID,FOLLOW_2); 

                    						newLeafNode(lv_attributes_7_0, grammarAccess.getVaraibleAccess().getAttributesIDTerminalRuleCall_2_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVaraibleRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"attributes",
                    							lv_attributes_7_0,
                    							"org.xtext.game.mygame.MyGames.ID");
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVaraible"


    // $ANTLR start "entryRuleIfStatement"
    // InternalMyGames.g:990:1: entryRuleIfStatement returns [EObject current=null] : iv_ruleIfStatement= ruleIfStatement EOF ;
    public final EObject entryRuleIfStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIfStatement = null;


        try {
            // InternalMyGames.g:990:52: (iv_ruleIfStatement= ruleIfStatement EOF )
            // InternalMyGames.g:991:2: iv_ruleIfStatement= ruleIfStatement EOF
            {
             newCompositeNode(grammarAccess.getIfStatementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIfStatement=ruleIfStatement();

            state._fsp--;

             current =iv_ruleIfStatement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIfStatement"


    // $ANTLR start "ruleIfStatement"
    // InternalMyGames.g:997:1: ruleIfStatement returns [EObject current=null] : (otherlv_0= 'if' otherlv_1= '(' ( (lv_condition_2_0= ruleExpression ) ) otherlv_3= ')' ( (lv_thenstatements_4_0= ruleNormalStatementBlock ) ) (otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) ) )? ) ;
    public final EObject ruleIfStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_condition_2_0 = null;

        EObject lv_thenstatements_4_0 = null;

        EObject lv_elsestatements_6_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1003:2: ( (otherlv_0= 'if' otherlv_1= '(' ( (lv_condition_2_0= ruleExpression ) ) otherlv_3= ')' ( (lv_thenstatements_4_0= ruleNormalStatementBlock ) ) (otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) ) )? ) )
            // InternalMyGames.g:1004:2: (otherlv_0= 'if' otherlv_1= '(' ( (lv_condition_2_0= ruleExpression ) ) otherlv_3= ')' ( (lv_thenstatements_4_0= ruleNormalStatementBlock ) ) (otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) ) )? )
            {
            // InternalMyGames.g:1004:2: (otherlv_0= 'if' otherlv_1= '(' ( (lv_condition_2_0= ruleExpression ) ) otherlv_3= ')' ( (lv_thenstatements_4_0= ruleNormalStatementBlock ) ) (otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) ) )? )
            // InternalMyGames.g:1005:3: otherlv_0= 'if' otherlv_1= '(' ( (lv_condition_2_0= ruleExpression ) ) otherlv_3= ')' ( (lv_thenstatements_4_0= ruleNormalStatementBlock ) ) (otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) ) )?
            {
            otherlv_0=(Token)match(input,36,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getIfStatementAccess().getIfKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_16); 

            			newLeafNode(otherlv_1, grammarAccess.getIfStatementAccess().getLeftParenthesisKeyword_1());
            		
            // InternalMyGames.g:1013:3: ( (lv_condition_2_0= ruleExpression ) )
            // InternalMyGames.g:1014:4: (lv_condition_2_0= ruleExpression )
            {
            // InternalMyGames.g:1014:4: (lv_condition_2_0= ruleExpression )
            // InternalMyGames.g:1015:5: lv_condition_2_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getIfStatementAccess().getConditionExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_23);
            lv_condition_2_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIfStatementRule());
            					}
            					set(
            						current,
            						"condition",
            						lv_condition_2_0,
            						"org.xtext.game.mygame.MyGames.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,15,FOLLOW_8); 

            			newLeafNode(otherlv_3, grammarAccess.getIfStatementAccess().getRightParenthesisKeyword_3());
            		
            // InternalMyGames.g:1036:3: ( (lv_thenstatements_4_0= ruleNormalStatementBlock ) )
            // InternalMyGames.g:1037:4: (lv_thenstatements_4_0= ruleNormalStatementBlock )
            {
            // InternalMyGames.g:1037:4: (lv_thenstatements_4_0= ruleNormalStatementBlock )
            // InternalMyGames.g:1038:5: lv_thenstatements_4_0= ruleNormalStatementBlock
            {

            					newCompositeNode(grammarAccess.getIfStatementAccess().getThenstatementsNormalStatementBlockParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_24);
            lv_thenstatements_4_0=ruleNormalStatementBlock();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIfStatementRule());
            					}
            					set(
            						current,
            						"thenstatements",
            						lv_thenstatements_4_0,
            						"org.xtext.game.mygame.MyGames.NormalStatementBlock");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyGames.g:1055:3: (otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==37) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalMyGames.g:1056:4: otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) )
                    {
                    otherlv_5=(Token)match(input,37,FOLLOW_8); 

                    				newLeafNode(otherlv_5, grammarAccess.getIfStatementAccess().getElseKeyword_5_0());
                    			
                    // InternalMyGames.g:1060:4: ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) )
                    // InternalMyGames.g:1061:5: (lv_elsestatements_6_0= ruleNormalStatementBlock )
                    {
                    // InternalMyGames.g:1061:5: (lv_elsestatements_6_0= ruleNormalStatementBlock )
                    // InternalMyGames.g:1062:6: lv_elsestatements_6_0= ruleNormalStatementBlock
                    {

                    						newCompositeNode(grammarAccess.getIfStatementAccess().getElsestatementsNormalStatementBlockParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_elsestatements_6_0=ruleNormalStatementBlock();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getIfStatementRule());
                    						}
                    						set(
                    							current,
                    							"elsestatements",
                    							lv_elsestatements_6_0,
                    							"org.xtext.game.mygame.MyGames.NormalStatementBlock");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIfStatement"


    // $ANTLR start "entryRuleForStatement"
    // InternalMyGames.g:1084:1: entryRuleForStatement returns [EObject current=null] : iv_ruleForStatement= ruleForStatement EOF ;
    public final EObject entryRuleForStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleForStatement = null;


        try {
            // InternalMyGames.g:1084:53: (iv_ruleForStatement= ruleForStatement EOF )
            // InternalMyGames.g:1085:2: iv_ruleForStatement= ruleForStatement EOF
            {
             newCompositeNode(grammarAccess.getForStatementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleForStatement=ruleForStatement();

            state._fsp--;

             current =iv_ruleForStatement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleForStatement"


    // $ANTLR start "ruleForStatement"
    // InternalMyGames.g:1091:1: ruleForStatement returns [EObject current=null] : (otherlv_0= 'for' otherlv_1= '(' ( (lv_iterator_2_0= ruleAssignmentStatement ) ) otherlv_3= ';' ( (lv_condition_4_0= ruleExpression ) ) otherlv_5= ';' ( (lv_iteratoroperation_6_0= ruleAssignmentStatement ) ) otherlv_7= ')' ( (lv_normalstatements_8_0= ruleNormalStatementBlock ) ) ) ;
    public final EObject ruleForStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        EObject lv_iterator_2_0 = null;

        EObject lv_condition_4_0 = null;

        EObject lv_iteratoroperation_6_0 = null;

        EObject lv_normalstatements_8_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1097:2: ( (otherlv_0= 'for' otherlv_1= '(' ( (lv_iterator_2_0= ruleAssignmentStatement ) ) otherlv_3= ';' ( (lv_condition_4_0= ruleExpression ) ) otherlv_5= ';' ( (lv_iteratoroperation_6_0= ruleAssignmentStatement ) ) otherlv_7= ')' ( (lv_normalstatements_8_0= ruleNormalStatementBlock ) ) ) )
            // InternalMyGames.g:1098:2: (otherlv_0= 'for' otherlv_1= '(' ( (lv_iterator_2_0= ruleAssignmentStatement ) ) otherlv_3= ';' ( (lv_condition_4_0= ruleExpression ) ) otherlv_5= ';' ( (lv_iteratoroperation_6_0= ruleAssignmentStatement ) ) otherlv_7= ')' ( (lv_normalstatements_8_0= ruleNormalStatementBlock ) ) )
            {
            // InternalMyGames.g:1098:2: (otherlv_0= 'for' otherlv_1= '(' ( (lv_iterator_2_0= ruleAssignmentStatement ) ) otherlv_3= ';' ( (lv_condition_4_0= ruleExpression ) ) otherlv_5= ';' ( (lv_iteratoroperation_6_0= ruleAssignmentStatement ) ) otherlv_7= ')' ( (lv_normalstatements_8_0= ruleNormalStatementBlock ) ) )
            // InternalMyGames.g:1099:3: otherlv_0= 'for' otherlv_1= '(' ( (lv_iterator_2_0= ruleAssignmentStatement ) ) otherlv_3= ';' ( (lv_condition_4_0= ruleExpression ) ) otherlv_5= ';' ( (lv_iteratoroperation_6_0= ruleAssignmentStatement ) ) otherlv_7= ')' ( (lv_normalstatements_8_0= ruleNormalStatementBlock ) )
            {
            otherlv_0=(Token)match(input,38,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getForStatementAccess().getForKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_25); 

            			newLeafNode(otherlv_1, grammarAccess.getForStatementAccess().getLeftParenthesisKeyword_1());
            		
            // InternalMyGames.g:1107:3: ( (lv_iterator_2_0= ruleAssignmentStatement ) )
            // InternalMyGames.g:1108:4: (lv_iterator_2_0= ruleAssignmentStatement )
            {
            // InternalMyGames.g:1108:4: (lv_iterator_2_0= ruleAssignmentStatement )
            // InternalMyGames.g:1109:5: lv_iterator_2_0= ruleAssignmentStatement
            {

            					newCompositeNode(grammarAccess.getForStatementAccess().getIteratorAssignmentStatementParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_10);
            lv_iterator_2_0=ruleAssignmentStatement();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getForStatementRule());
            					}
            					set(
            						current,
            						"iterator",
            						lv_iterator_2_0,
            						"org.xtext.game.mygame.MyGames.AssignmentStatement");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,17,FOLLOW_16); 

            			newLeafNode(otherlv_3, grammarAccess.getForStatementAccess().getSemicolonKeyword_3());
            		
            // InternalMyGames.g:1130:3: ( (lv_condition_4_0= ruleExpression ) )
            // InternalMyGames.g:1131:4: (lv_condition_4_0= ruleExpression )
            {
            // InternalMyGames.g:1131:4: (lv_condition_4_0= ruleExpression )
            // InternalMyGames.g:1132:5: lv_condition_4_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getForStatementAccess().getConditionExpressionParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_10);
            lv_condition_4_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getForStatementRule());
            					}
            					set(
            						current,
            						"condition",
            						lv_condition_4_0,
            						"org.xtext.game.mygame.MyGames.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,17,FOLLOW_25); 

            			newLeafNode(otherlv_5, grammarAccess.getForStatementAccess().getSemicolonKeyword_5());
            		
            // InternalMyGames.g:1153:3: ( (lv_iteratoroperation_6_0= ruleAssignmentStatement ) )
            // InternalMyGames.g:1154:4: (lv_iteratoroperation_6_0= ruleAssignmentStatement )
            {
            // InternalMyGames.g:1154:4: (lv_iteratoroperation_6_0= ruleAssignmentStatement )
            // InternalMyGames.g:1155:5: lv_iteratoroperation_6_0= ruleAssignmentStatement
            {

            					newCompositeNode(grammarAccess.getForStatementAccess().getIteratoroperationAssignmentStatementParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_23);
            lv_iteratoroperation_6_0=ruleAssignmentStatement();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getForStatementRule());
            					}
            					set(
            						current,
            						"iteratoroperation",
            						lv_iteratoroperation_6_0,
            						"org.xtext.game.mygame.MyGames.AssignmentStatement");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_7=(Token)match(input,15,FOLLOW_8); 

            			newLeafNode(otherlv_7, grammarAccess.getForStatementAccess().getRightParenthesisKeyword_7());
            		
            // InternalMyGames.g:1176:3: ( (lv_normalstatements_8_0= ruleNormalStatementBlock ) )
            // InternalMyGames.g:1177:4: (lv_normalstatements_8_0= ruleNormalStatementBlock )
            {
            // InternalMyGames.g:1177:4: (lv_normalstatements_8_0= ruleNormalStatementBlock )
            // InternalMyGames.g:1178:5: lv_normalstatements_8_0= ruleNormalStatementBlock
            {

            					newCompositeNode(grammarAccess.getForStatementAccess().getNormalstatementsNormalStatementBlockParserRuleCall_8_0());
            				
            pushFollow(FOLLOW_2);
            lv_normalstatements_8_0=ruleNormalStatementBlock();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getForStatementRule());
            					}
            					set(
            						current,
            						"normalstatements",
            						lv_normalstatements_8_0,
            						"org.xtext.game.mygame.MyGames.NormalStatementBlock");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleForStatement"


    // $ANTLR start "entryRuleExpression"
    // InternalMyGames.g:1199:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalMyGames.g:1199:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalMyGames.g:1200:2: iv_ruleExpression= ruleExpression EOF
            {
             newCompositeNode(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;

             current =iv_ruleExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalMyGames.g:1206:1: ruleExpression returns [EObject current=null] : this_RelationExpression_0= ruleRelationExpression ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_RelationExpression_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1212:2: (this_RelationExpression_0= ruleRelationExpression )
            // InternalMyGames.g:1213:2: this_RelationExpression_0= ruleRelationExpression
            {

            		newCompositeNode(grammarAccess.getExpressionAccess().getRelationExpressionParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_RelationExpression_0=ruleRelationExpression();

            state._fsp--;


            		current = this_RelationExpression_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleRelationExpression"
    // InternalMyGames.g:1224:1: entryRuleRelationExpression returns [EObject current=null] : iv_ruleRelationExpression= ruleRelationExpression EOF ;
    public final EObject entryRuleRelationExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRelationExpression = null;


        try {
            // InternalMyGames.g:1224:59: (iv_ruleRelationExpression= ruleRelationExpression EOF )
            // InternalMyGames.g:1225:2: iv_ruleRelationExpression= ruleRelationExpression EOF
            {
             newCompositeNode(grammarAccess.getRelationExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRelationExpression=ruleRelationExpression();

            state._fsp--;

             current =iv_ruleRelationExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRelationExpression"


    // $ANTLR start "ruleRelationExpression"
    // InternalMyGames.g:1231:1: ruleRelationExpression returns [EObject current=null] : (this_AdditionExpression_0= ruleAdditionExpression ( ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) ) )* ) ;
    public final EObject ruleRelationExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject this_AdditionExpression_0 = null;

        EObject lv_right_5_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1237:2: ( (this_AdditionExpression_0= ruleAdditionExpression ( ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) ) )* ) )
            // InternalMyGames.g:1238:2: (this_AdditionExpression_0= ruleAdditionExpression ( ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) ) )* )
            {
            // InternalMyGames.g:1238:2: (this_AdditionExpression_0= ruleAdditionExpression ( ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) ) )* )
            // InternalMyGames.g:1239:3: this_AdditionExpression_0= ruleAdditionExpression ( ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) ) )*
            {

            			newCompositeNode(grammarAccess.getRelationExpressionAccess().getAdditionExpressionParserRuleCall_0());
            		
            pushFollow(FOLLOW_26);
            this_AdditionExpression_0=ruleAdditionExpression();

            state._fsp--;


            			current = this_AdditionExpression_0;
            			afterParserOrEnumRuleCall();
            		
            // InternalMyGames.g:1247:3: ( ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) ) )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( ((LA18_0>=39 && LA18_0<=40)) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalMyGames.g:1248:4: ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) )
            	    {
            	    // InternalMyGames.g:1248:4: ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) )
            	    int alt17=2;
            	    int LA17_0 = input.LA(1);

            	    if ( (LA17_0==39) ) {
            	        alt17=1;
            	    }
            	    else if ( (LA17_0==40) ) {
            	        alt17=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 17, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt17) {
            	        case 1 :
            	            // InternalMyGames.g:1249:5: ( () otherlv_2= '==' )
            	            {
            	            // InternalMyGames.g:1249:5: ( () otherlv_2= '==' )
            	            // InternalMyGames.g:1250:6: () otherlv_2= '=='
            	            {
            	            // InternalMyGames.g:1250:6: ()
            	            // InternalMyGames.g:1251:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getRelationExpressionAccess().getEqualsLeftAction_1_0_0_0(),
            	            								current);
            	            						

            	            }

            	            otherlv_2=(Token)match(input,39,FOLLOW_16); 

            	            						newLeafNode(otherlv_2, grammarAccess.getRelationExpressionAccess().getEqualsSignEqualsSignKeyword_1_0_0_1());
            	            					

            	            }


            	            }
            	            break;
            	        case 2 :
            	            // InternalMyGames.g:1263:5: ( () otherlv_4= '<' )
            	            {
            	            // InternalMyGames.g:1263:5: ( () otherlv_4= '<' )
            	            // InternalMyGames.g:1264:6: () otherlv_4= '<'
            	            {
            	            // InternalMyGames.g:1264:6: ()
            	            // InternalMyGames.g:1265:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getRelationExpressionAccess().getLessLeftAction_1_0_1_0(),
            	            								current);
            	            						

            	            }

            	            otherlv_4=(Token)match(input,40,FOLLOW_16); 

            	            						newLeafNode(otherlv_4, grammarAccess.getRelationExpressionAccess().getLessThanSignKeyword_1_0_1_1());
            	            					

            	            }


            	            }
            	            break;

            	    }

            	    // InternalMyGames.g:1277:4: ( (lv_right_5_0= ruleAdditionExpression ) )
            	    // InternalMyGames.g:1278:5: (lv_right_5_0= ruleAdditionExpression )
            	    {
            	    // InternalMyGames.g:1278:5: (lv_right_5_0= ruleAdditionExpression )
            	    // InternalMyGames.g:1279:6: lv_right_5_0= ruleAdditionExpression
            	    {

            	    						newCompositeNode(grammarAccess.getRelationExpressionAccess().getRightAdditionExpressionParserRuleCall_1_1_0());
            	    					
            	    pushFollow(FOLLOW_26);
            	    lv_right_5_0=ruleAdditionExpression();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getRelationExpressionRule());
            	    						}
            	    						set(
            	    							current,
            	    							"right",
            	    							lv_right_5_0,
            	    							"org.xtext.game.mygame.MyGames.AdditionExpression");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRelationExpression"


    // $ANTLR start "entryRuleAdditionExpression"
    // InternalMyGames.g:1301:1: entryRuleAdditionExpression returns [EObject current=null] : iv_ruleAdditionExpression= ruleAdditionExpression EOF ;
    public final EObject entryRuleAdditionExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAdditionExpression = null;


        try {
            // InternalMyGames.g:1301:59: (iv_ruleAdditionExpression= ruleAdditionExpression EOF )
            // InternalMyGames.g:1302:2: iv_ruleAdditionExpression= ruleAdditionExpression EOF
            {
             newCompositeNode(grammarAccess.getAdditionExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAdditionExpression=ruleAdditionExpression();

            state._fsp--;

             current =iv_ruleAdditionExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAdditionExpression"


    // $ANTLR start "ruleAdditionExpression"
    // InternalMyGames.g:1308:1: ruleAdditionExpression returns [EObject current=null] : (this_MultiplyExpression_0= ruleMultiplyExpression ( ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) ) )* ) ;
    public final EObject ruleAdditionExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject this_MultiplyExpression_0 = null;

        EObject lv_right_5_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1314:2: ( (this_MultiplyExpression_0= ruleMultiplyExpression ( ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) ) )* ) )
            // InternalMyGames.g:1315:2: (this_MultiplyExpression_0= ruleMultiplyExpression ( ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) ) )* )
            {
            // InternalMyGames.g:1315:2: (this_MultiplyExpression_0= ruleMultiplyExpression ( ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) ) )* )
            // InternalMyGames.g:1316:3: this_MultiplyExpression_0= ruleMultiplyExpression ( ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) ) )*
            {

            			newCompositeNode(grammarAccess.getAdditionExpressionAccess().getMultiplyExpressionParserRuleCall_0());
            		
            pushFollow(FOLLOW_27);
            this_MultiplyExpression_0=ruleMultiplyExpression();

            state._fsp--;


            			current = this_MultiplyExpression_0;
            			afterParserOrEnumRuleCall();
            		
            // InternalMyGames.g:1324:3: ( ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) ) )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( ((LA20_0>=41 && LA20_0<=42)) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalMyGames.g:1325:4: ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) )
            	    {
            	    // InternalMyGames.g:1325:4: ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) )
            	    int alt19=2;
            	    int LA19_0 = input.LA(1);

            	    if ( (LA19_0==41) ) {
            	        alt19=1;
            	    }
            	    else if ( (LA19_0==42) ) {
            	        alt19=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 19, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt19) {
            	        case 1 :
            	            // InternalMyGames.g:1326:5: ( () otherlv_2= '+' )
            	            {
            	            // InternalMyGames.g:1326:5: ( () otherlv_2= '+' )
            	            // InternalMyGames.g:1327:6: () otherlv_2= '+'
            	            {
            	            // InternalMyGames.g:1327:6: ()
            	            // InternalMyGames.g:1328:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getAdditionExpressionAccess().getAddLeftAction_1_0_0_0(),
            	            								current);
            	            						

            	            }

            	            otherlv_2=(Token)match(input,41,FOLLOW_16); 

            	            						newLeafNode(otherlv_2, grammarAccess.getAdditionExpressionAccess().getPlusSignKeyword_1_0_0_1());
            	            					

            	            }


            	            }
            	            break;
            	        case 2 :
            	            // InternalMyGames.g:1340:5: ( () otherlv_4= '-' )
            	            {
            	            // InternalMyGames.g:1340:5: ( () otherlv_4= '-' )
            	            // InternalMyGames.g:1341:6: () otherlv_4= '-'
            	            {
            	            // InternalMyGames.g:1341:6: ()
            	            // InternalMyGames.g:1342:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getAdditionExpressionAccess().getMinusLeftAction_1_0_1_0(),
            	            								current);
            	            						

            	            }

            	            otherlv_4=(Token)match(input,42,FOLLOW_16); 

            	            						newLeafNode(otherlv_4, grammarAccess.getAdditionExpressionAccess().getHyphenMinusKeyword_1_0_1_1());
            	            					

            	            }


            	            }
            	            break;

            	    }

            	    // InternalMyGames.g:1354:4: ( (lv_right_5_0= ruleMultiplyExpression ) )
            	    // InternalMyGames.g:1355:5: (lv_right_5_0= ruleMultiplyExpression )
            	    {
            	    // InternalMyGames.g:1355:5: (lv_right_5_0= ruleMultiplyExpression )
            	    // InternalMyGames.g:1356:6: lv_right_5_0= ruleMultiplyExpression
            	    {

            	    						newCompositeNode(grammarAccess.getAdditionExpressionAccess().getRightMultiplyExpressionParserRuleCall_1_1_0());
            	    					
            	    pushFollow(FOLLOW_27);
            	    lv_right_5_0=ruleMultiplyExpression();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getAdditionExpressionRule());
            	    						}
            	    						set(
            	    							current,
            	    							"right",
            	    							lv_right_5_0,
            	    							"org.xtext.game.mygame.MyGames.MultiplyExpression");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAdditionExpression"


    // $ANTLR start "entryRuleMultiplyExpression"
    // InternalMyGames.g:1378:1: entryRuleMultiplyExpression returns [EObject current=null] : iv_ruleMultiplyExpression= ruleMultiplyExpression EOF ;
    public final EObject entryRuleMultiplyExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMultiplyExpression = null;


        try {
            // InternalMyGames.g:1378:59: (iv_ruleMultiplyExpression= ruleMultiplyExpression EOF )
            // InternalMyGames.g:1379:2: iv_ruleMultiplyExpression= ruleMultiplyExpression EOF
            {
             newCompositeNode(grammarAccess.getMultiplyExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMultiplyExpression=ruleMultiplyExpression();

            state._fsp--;

             current =iv_ruleMultiplyExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMultiplyExpression"


    // $ANTLR start "ruleMultiplyExpression"
    // InternalMyGames.g:1385:1: ruleMultiplyExpression returns [EObject current=null] : (this_NegationExpression_0= ruleNegationExpression ( ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) ) )* ) ;
    public final EObject ruleMultiplyExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject this_NegationExpression_0 = null;

        EObject lv_right_5_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1391:2: ( (this_NegationExpression_0= ruleNegationExpression ( ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) ) )* ) )
            // InternalMyGames.g:1392:2: (this_NegationExpression_0= ruleNegationExpression ( ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) ) )* )
            {
            // InternalMyGames.g:1392:2: (this_NegationExpression_0= ruleNegationExpression ( ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) ) )* )
            // InternalMyGames.g:1393:3: this_NegationExpression_0= ruleNegationExpression ( ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) ) )*
            {

            			newCompositeNode(grammarAccess.getMultiplyExpressionAccess().getNegationExpressionParserRuleCall_0());
            		
            pushFollow(FOLLOW_28);
            this_NegationExpression_0=ruleNegationExpression();

            state._fsp--;


            			current = this_NegationExpression_0;
            			afterParserOrEnumRuleCall();
            		
            // InternalMyGames.g:1401:3: ( ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) ) )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( ((LA22_0>=43 && LA22_0<=44)) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // InternalMyGames.g:1402:4: ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) )
            	    {
            	    // InternalMyGames.g:1402:4: ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) )
            	    int alt21=2;
            	    int LA21_0 = input.LA(1);

            	    if ( (LA21_0==43) ) {
            	        alt21=1;
            	    }
            	    else if ( (LA21_0==44) ) {
            	        alt21=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 21, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt21) {
            	        case 1 :
            	            // InternalMyGames.g:1403:5: ( () otherlv_2= '/' )
            	            {
            	            // InternalMyGames.g:1403:5: ( () otherlv_2= '/' )
            	            // InternalMyGames.g:1404:6: () otherlv_2= '/'
            	            {
            	            // InternalMyGames.g:1404:6: ()
            	            // InternalMyGames.g:1405:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getMultiplyExpressionAccess().getDivideLeftAction_1_0_0_0(),
            	            								current);
            	            						

            	            }

            	            otherlv_2=(Token)match(input,43,FOLLOW_16); 

            	            						newLeafNode(otherlv_2, grammarAccess.getMultiplyExpressionAccess().getSolidusKeyword_1_0_0_1());
            	            					

            	            }


            	            }
            	            break;
            	        case 2 :
            	            // InternalMyGames.g:1417:5: ( () otherlv_4= '*' )
            	            {
            	            // InternalMyGames.g:1417:5: ( () otherlv_4= '*' )
            	            // InternalMyGames.g:1418:6: () otherlv_4= '*'
            	            {
            	            // InternalMyGames.g:1418:6: ()
            	            // InternalMyGames.g:1419:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getMultiplyExpressionAccess().getMultiplyLeftAction_1_0_1_0(),
            	            								current);
            	            						

            	            }

            	            otherlv_4=(Token)match(input,44,FOLLOW_16); 

            	            						newLeafNode(otherlv_4, grammarAccess.getMultiplyExpressionAccess().getAsteriskKeyword_1_0_1_1());
            	            					

            	            }


            	            }
            	            break;

            	    }

            	    // InternalMyGames.g:1431:4: ( (lv_right_5_0= ruleNegationExpression ) )
            	    // InternalMyGames.g:1432:5: (lv_right_5_0= ruleNegationExpression )
            	    {
            	    // InternalMyGames.g:1432:5: (lv_right_5_0= ruleNegationExpression )
            	    // InternalMyGames.g:1433:6: lv_right_5_0= ruleNegationExpression
            	    {

            	    						newCompositeNode(grammarAccess.getMultiplyExpressionAccess().getRightNegationExpressionParserRuleCall_1_1_0());
            	    					
            	    pushFollow(FOLLOW_28);
            	    lv_right_5_0=ruleNegationExpression();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getMultiplyExpressionRule());
            	    						}
            	    						set(
            	    							current,
            	    							"right",
            	    							lv_right_5_0,
            	    							"org.xtext.game.mygame.MyGames.NegationExpression");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMultiplyExpression"


    // $ANTLR start "entryRuleNegationExpression"
    // InternalMyGames.g:1455:1: entryRuleNegationExpression returns [EObject current=null] : iv_ruleNegationExpression= ruleNegationExpression EOF ;
    public final EObject entryRuleNegationExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNegationExpression = null;


        try {
            // InternalMyGames.g:1455:59: (iv_ruleNegationExpression= ruleNegationExpression EOF )
            // InternalMyGames.g:1456:2: iv_ruleNegationExpression= ruleNegationExpression EOF
            {
             newCompositeNode(grammarAccess.getNegationExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNegationExpression=ruleNegationExpression();

            state._fsp--;

             current =iv_ruleNegationExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNegationExpression"


    // $ANTLR start "ruleNegationExpression"
    // InternalMyGames.g:1462:1: ruleNegationExpression returns [EObject current=null] : ( ( ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) ) ) | this_BoolExpression_3= ruleBoolExpression ) ;
    public final EObject ruleNegationExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_expression_2_0 = null;

        EObject this_BoolExpression_3 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1468:2: ( ( ( ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) ) ) | this_BoolExpression_3= ruleBoolExpression ) )
            // InternalMyGames.g:1469:2: ( ( ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) ) ) | this_BoolExpression_3= ruleBoolExpression )
            {
            // InternalMyGames.g:1469:2: ( ( ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) ) ) | this_BoolExpression_3= ruleBoolExpression )
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==45) ) {
                alt23=1;
            }
            else if ( ((LA23_0>=RULE_ID && LA23_0<=RULE_NUMBER)||LA23_0==13) ) {
                alt23=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }
            switch (alt23) {
                case 1 :
                    // InternalMyGames.g:1470:3: ( ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) ) )
                    {
                    // InternalMyGames.g:1470:3: ( ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) ) )
                    // InternalMyGames.g:1471:4: ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) )
                    {
                    // InternalMyGames.g:1471:4: ( () otherlv_1= '!' )
                    // InternalMyGames.g:1472:5: () otherlv_1= '!'
                    {
                    // InternalMyGames.g:1472:5: ()
                    // InternalMyGames.g:1473:6: 
                    {

                    						current = forceCreateModelElement(
                    							grammarAccess.getNegationExpressionAccess().getNegationAction_0_0_0(),
                    							current);
                    					

                    }

                    otherlv_1=(Token)match(input,45,FOLLOW_16); 

                    					newLeafNode(otherlv_1, grammarAccess.getNegationExpressionAccess().getExclamationMarkKeyword_0_0_1());
                    				

                    }

                    // InternalMyGames.g:1484:4: ( (lv_expression_2_0= ruleNegationExpression ) )
                    // InternalMyGames.g:1485:5: (lv_expression_2_0= ruleNegationExpression )
                    {
                    // InternalMyGames.g:1485:5: (lv_expression_2_0= ruleNegationExpression )
                    // InternalMyGames.g:1486:6: lv_expression_2_0= ruleNegationExpression
                    {

                    						newCompositeNode(grammarAccess.getNegationExpressionAccess().getExpressionNegationExpressionParserRuleCall_0_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_expression_2_0=ruleNegationExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getNegationExpressionRule());
                    						}
                    						set(
                    							current,
                    							"expression",
                    							lv_expression_2_0,
                    							"org.xtext.game.mygame.MyGames.NegationExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyGames.g:1505:3: this_BoolExpression_3= ruleBoolExpression
                    {

                    			newCompositeNode(grammarAccess.getNegationExpressionAccess().getBoolExpressionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_BoolExpression_3=ruleBoolExpression();

                    state._fsp--;


                    			current = this_BoolExpression_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNegationExpression"


    // $ANTLR start "entryRuleBoolExpression"
    // InternalMyGames.g:1517:1: entryRuleBoolExpression returns [EObject current=null] : iv_ruleBoolExpression= ruleBoolExpression EOF ;
    public final EObject entryRuleBoolExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBoolExpression = null;


        try {
            // InternalMyGames.g:1517:55: (iv_ruleBoolExpression= ruleBoolExpression EOF )
            // InternalMyGames.g:1518:2: iv_ruleBoolExpression= ruleBoolExpression EOF
            {
             newCompositeNode(grammarAccess.getBoolExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBoolExpression=ruleBoolExpression();

            state._fsp--;

             current =iv_ruleBoolExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBoolExpression"


    // $ANTLR start "ruleBoolExpression"
    // InternalMyGames.g:1524:1: ruleBoolExpression returns [EObject current=null] : ( ( () ( (lv_value_1_0= RULE_NUMBER ) ) ) | this_Varaible_2= ruleVaraible | (otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')' ) ) ;
    public final EObject ruleBoolExpression() throws RecognitionException {
        EObject current = null;

        Token lv_value_1_0=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject this_Varaible_2 = null;

        EObject this_Expression_4 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1530:2: ( ( ( () ( (lv_value_1_0= RULE_NUMBER ) ) ) | this_Varaible_2= ruleVaraible | (otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')' ) ) )
            // InternalMyGames.g:1531:2: ( ( () ( (lv_value_1_0= RULE_NUMBER ) ) ) | this_Varaible_2= ruleVaraible | (otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')' ) )
            {
            // InternalMyGames.g:1531:2: ( ( () ( (lv_value_1_0= RULE_NUMBER ) ) ) | this_Varaible_2= ruleVaraible | (otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')' ) )
            int alt24=3;
            switch ( input.LA(1) ) {
            case RULE_NUMBER:
                {
                alt24=1;
                }
                break;
            case RULE_ID:
                {
                alt24=2;
                }
                break;
            case 13:
                {
                alt24=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }

            switch (alt24) {
                case 1 :
                    // InternalMyGames.g:1532:3: ( () ( (lv_value_1_0= RULE_NUMBER ) ) )
                    {
                    // InternalMyGames.g:1532:3: ( () ( (lv_value_1_0= RULE_NUMBER ) ) )
                    // InternalMyGames.g:1533:4: () ( (lv_value_1_0= RULE_NUMBER ) )
                    {
                    // InternalMyGames.g:1533:4: ()
                    // InternalMyGames.g:1534:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getBoolExpressionAccess().getNumberLiteralAction_0_0(),
                    						current);
                    				

                    }

                    // InternalMyGames.g:1540:4: ( (lv_value_1_0= RULE_NUMBER ) )
                    // InternalMyGames.g:1541:5: (lv_value_1_0= RULE_NUMBER )
                    {
                    // InternalMyGames.g:1541:5: (lv_value_1_0= RULE_NUMBER )
                    // InternalMyGames.g:1542:6: lv_value_1_0= RULE_NUMBER
                    {
                    lv_value_1_0=(Token)match(input,RULE_NUMBER,FOLLOW_2); 

                    						newLeafNode(lv_value_1_0, grammarAccess.getBoolExpressionAccess().getValueNUMBERTerminalRuleCall_0_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getBoolExpressionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"value",
                    							lv_value_1_0,
                    							"org.xtext.game.mygame.MyGames.NUMBER");
                    					

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyGames.g:1560:3: this_Varaible_2= ruleVaraible
                    {

                    			newCompositeNode(grammarAccess.getBoolExpressionAccess().getVaraibleParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Varaible_2=ruleVaraible();

                    state._fsp--;


                    			current = this_Varaible_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMyGames.g:1569:3: (otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')' )
                    {
                    // InternalMyGames.g:1569:3: (otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')' )
                    // InternalMyGames.g:1570:4: otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')'
                    {
                    otherlv_3=(Token)match(input,13,FOLLOW_16); 

                    				newLeafNode(otherlv_3, grammarAccess.getBoolExpressionAccess().getLeftParenthesisKeyword_2_0());
                    			

                    				newCompositeNode(grammarAccess.getBoolExpressionAccess().getExpressionParserRuleCall_2_1());
                    			
                    pushFollow(FOLLOW_23);
                    this_Expression_4=ruleExpression();

                    state._fsp--;


                    				current = this_Expression_4;
                    				afterParserOrEnumRuleCall();
                    			
                    otherlv_5=(Token)match(input,15,FOLLOW_2); 

                    				newLeafNode(otherlv_5, grammarAccess.getBoolExpressionAccess().getRightParenthesisKeyword_2_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBoolExpression"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000008010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x000000000000C000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000004050000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000010000002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000001E00000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000082000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000200000002030L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x00000001E0000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000005400000010L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000800080002L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000800000002L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000002000000002L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000005000000010L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000018000000002L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000060000000002L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000180000000002L});

}
package org.xtext.game.mygame.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.game.mygame.services.MyGamesGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyGamesParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_NUMBER", "RULE_WS", "RULE_ANY_OTHER", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "'Mainwindow'", "'('", "','", "')'", "'Main'", "';'", "'['", "']'", "'Player'", "'Obstacle'", "'GameProps'", "'Destination'", "'='", "'Var'", "'int'", "'Trigger'", "'UP'", "'DOWN'", "'LEFT'", "'RIGHT'", "'{'", "'}'", "'.'", "'if'", "'else'", "'for'", "'=='", "'<'", "'+'", "'-'", "'/'", "'*'", "'!'"
    };
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=8;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=10;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=9;
    public static final int RULE_SL_COMMENT=11;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=6;
    public static final int RULE_ANY_OTHER=7;
    public static final int RULE_NUMBER=5;
    public static final int T__44=44;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalMyGamesParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyGamesParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyGamesParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyGames.g"; }



     	private MyGamesGrammarAccess grammarAccess;

        public InternalMyGamesParser(TokenStream input, MyGamesGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Minigames";
       	}

       	@Override
       	protected MyGamesGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleMinigames"
    // InternalMyGames.g:64:1: entryRuleMinigames returns [EObject current=null] : iv_ruleMinigames= ruleMinigames EOF ;
    public final EObject entryRuleMinigames() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMinigames = null;


        try {
            // InternalMyGames.g:64:50: (iv_ruleMinigames= ruleMinigames EOF )
            // InternalMyGames.g:65:2: iv_ruleMinigames= ruleMinigames EOF
            {
             newCompositeNode(grammarAccess.getMinigamesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMinigames=ruleMinigames();

            state._fsp--;

             current =iv_ruleMinigames; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMinigames"


    // $ANTLR start "ruleMinigames"
    // InternalMyGames.g:71:1: ruleMinigames returns [EObject current=null] : (otherlv_0= 'Mainwindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ( (lv_DeclarationSet_7_0= ruleVariableDeclaration ) )* otherlv_8= 'Main' ( (lv_Constructor_9_0= ruleNormalStatementBlock ) ) ( (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock ) )* ) ;
    public final EObject ruleMinigames() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        EObject lv_Formalparameter_3_0 = null;

        EObject lv_Formalparameter_5_0 = null;

        EObject lv_DeclarationSet_7_0 = null;

        EObject lv_Constructor_9_0 = null;

        EObject lv_KeyPressEvents_10_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:77:2: ( (otherlv_0= 'Mainwindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ( (lv_DeclarationSet_7_0= ruleVariableDeclaration ) )* otherlv_8= 'Main' ( (lv_Constructor_9_0= ruleNormalStatementBlock ) ) ( (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock ) )* ) )
            // InternalMyGames.g:78:2: (otherlv_0= 'Mainwindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ( (lv_DeclarationSet_7_0= ruleVariableDeclaration ) )* otherlv_8= 'Main' ( (lv_Constructor_9_0= ruleNormalStatementBlock ) ) ( (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock ) )* )
            {
            // InternalMyGames.g:78:2: (otherlv_0= 'Mainwindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ( (lv_DeclarationSet_7_0= ruleVariableDeclaration ) )* otherlv_8= 'Main' ( (lv_Constructor_9_0= ruleNormalStatementBlock ) ) ( (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock ) )* )
            // InternalMyGames.g:79:3: otherlv_0= 'Mainwindow' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ( (lv_DeclarationSet_7_0= ruleVariableDeclaration ) )* otherlv_8= 'Main' ( (lv_Constructor_9_0= ruleNormalStatementBlock ) ) ( (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock ) )*
            {
            otherlv_0=(Token)match(input,12,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getMinigamesAccess().getMainwindowKeyword_0());
            		
            // InternalMyGames.g:83:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalMyGames.g:84:4: (lv_name_1_0= RULE_ID )
            {
            // InternalMyGames.g:84:4: (lv_name_1_0= RULE_ID )
            // InternalMyGames.g:85:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_name_1_0, grammarAccess.getMinigamesAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMinigamesRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.xtext.game.mygame.MyGames.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_5); 

            			newLeafNode(otherlv_2, grammarAccess.getMinigamesAccess().getLeftParenthesisKeyword_2());
            		
            // InternalMyGames.g:105:3: ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==RULE_ID) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalMyGames.g:106:4: ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )*
                    {
                    // InternalMyGames.g:106:4: ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) )
                    // InternalMyGames.g:107:5: (lv_Formalparameter_3_0= ruleFormalparameterSet )
                    {
                    // InternalMyGames.g:107:5: (lv_Formalparameter_3_0= ruleFormalparameterSet )
                    // InternalMyGames.g:108:6: lv_Formalparameter_3_0= ruleFormalparameterSet
                    {

                    						newCompositeNode(grammarAccess.getMinigamesAccess().getFormalparameterFormalparameterSetParserRuleCall_3_0_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_Formalparameter_3_0=ruleFormalparameterSet();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMinigamesRule());
                    						}
                    						add(
                    							current,
                    							"Formalparameter",
                    							lv_Formalparameter_3_0,
                    							"org.xtext.game.mygame.MyGames.FormalparameterSet");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMyGames.g:125:4: (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )*
                    loop1:
                    do {
                        int alt1=2;
                        int LA1_0 = input.LA(1);

                        if ( (LA1_0==14) ) {
                            alt1=1;
                        }


                        switch (alt1) {
                    	case 1 :
                    	    // InternalMyGames.g:126:5: otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) )
                    	    {
                    	    otherlv_4=(Token)match(input,14,FOLLOW_3); 

                    	    					newLeafNode(otherlv_4, grammarAccess.getMinigamesAccess().getCommaKeyword_3_1_0());
                    	    				
                    	    // InternalMyGames.g:130:5: ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) )
                    	    // InternalMyGames.g:131:6: (lv_Formalparameter_5_0= ruleFormalparameterSet )
                    	    {
                    	    // InternalMyGames.g:131:6: (lv_Formalparameter_5_0= ruleFormalparameterSet )
                    	    // InternalMyGames.g:132:7: lv_Formalparameter_5_0= ruleFormalparameterSet
                    	    {

                    	    							newCompositeNode(grammarAccess.getMinigamesAccess().getFormalparameterFormalparameterSetParserRuleCall_3_1_1_0());
                    	    						
                    	    pushFollow(FOLLOW_6);
                    	    lv_Formalparameter_5_0=ruleFormalparameterSet();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getMinigamesRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"Formalparameter",
                    	    								lv_Formalparameter_5_0,
                    	    								"org.xtext.game.mygame.MyGames.FormalparameterSet");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop1;
                        }
                    } while (true);


                    }
                    break;

            }

            otherlv_6=(Token)match(input,15,FOLLOW_7); 

            			newLeafNode(otherlv_6, grammarAccess.getMinigamesAccess().getRightParenthesisKeyword_4());
            		
            // InternalMyGames.g:155:3: ( (lv_DeclarationSet_7_0= ruleVariableDeclaration ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( ((LA3_0>=20 && LA3_0<=23)||LA3_0==25) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalMyGames.g:156:4: (lv_DeclarationSet_7_0= ruleVariableDeclaration )
            	    {
            	    // InternalMyGames.g:156:4: (lv_DeclarationSet_7_0= ruleVariableDeclaration )
            	    // InternalMyGames.g:157:5: lv_DeclarationSet_7_0= ruleVariableDeclaration
            	    {

            	    					newCompositeNode(grammarAccess.getMinigamesAccess().getDeclarationSetVariableDeclarationParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_7);
            	    lv_DeclarationSet_7_0=ruleVariableDeclaration();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getMinigamesRule());
            	    					}
            	    					add(
            	    						current,
            	    						"DeclarationSet",
            	    						lv_DeclarationSet_7_0,
            	    						"org.xtext.game.mygame.MyGames.VariableDeclaration");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            otherlv_8=(Token)match(input,16,FOLLOW_8); 

            			newLeafNode(otherlv_8, grammarAccess.getMinigamesAccess().getMainKeyword_6());
            		
            // InternalMyGames.g:178:3: ( (lv_Constructor_9_0= ruleNormalStatementBlock ) )
            // InternalMyGames.g:179:4: (lv_Constructor_9_0= ruleNormalStatementBlock )
            {
            // InternalMyGames.g:179:4: (lv_Constructor_9_0= ruleNormalStatementBlock )
            // InternalMyGames.g:180:5: lv_Constructor_9_0= ruleNormalStatementBlock
            {

            					newCompositeNode(grammarAccess.getMinigamesAccess().getConstructorNormalStatementBlockParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_9);
            lv_Constructor_9_0=ruleNormalStatementBlock();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMinigamesRule());
            					}
            					set(
            						current,
            						"Constructor",
            						lv_Constructor_9_0,
            						"org.xtext.game.mygame.MyGames.NormalStatementBlock");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyGames.g:197:3: ( (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==27) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalMyGames.g:198:4: (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock )
            	    {
            	    // InternalMyGames.g:198:4: (lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock )
            	    // InternalMyGames.g:199:5: lv_KeyPressEvents_10_0= ruleKeyPressEventsBlock
            	    {

            	    					newCompositeNode(grammarAccess.getMinigamesAccess().getKeyPressEventsKeyPressEventsBlockParserRuleCall_8_0());
            	    				
            	    pushFollow(FOLLOW_9);
            	    lv_KeyPressEvents_10_0=ruleKeyPressEventsBlock();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getMinigamesRule());
            	    					}
            	    					add(
            	    						current,
            	    						"KeyPressEvents",
            	    						lv_KeyPressEvents_10_0,
            	    						"org.xtext.game.mygame.MyGames.KeyPressEventsBlock");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMinigames"


    // $ANTLR start "entryRuleVariableDeclaration"
    // InternalMyGames.g:220:1: entryRuleVariableDeclaration returns [EObject current=null] : iv_ruleVariableDeclaration= ruleVariableDeclaration EOF ;
    public final EObject entryRuleVariableDeclaration() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariableDeclaration = null;


        try {
            // InternalMyGames.g:220:60: (iv_ruleVariableDeclaration= ruleVariableDeclaration EOF )
            // InternalMyGames.g:221:2: iv_ruleVariableDeclaration= ruleVariableDeclaration EOF
            {
             newCompositeNode(grammarAccess.getVariableDeclarationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariableDeclaration=ruleVariableDeclaration();

            state._fsp--;

             current =iv_ruleVariableDeclaration; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariableDeclaration"


    // $ANTLR start "ruleVariableDeclaration"
    // InternalMyGames.g:227:1: ruleVariableDeclaration returns [EObject current=null] : ( (this_IntegerDeclaration_0= ruleIntegerDeclaration | this_CharacterDeclaration_1= ruleCharacterDeclaration ) otherlv_2= ';' ) ;
    public final EObject ruleVariableDeclaration() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        EObject this_IntegerDeclaration_0 = null;

        EObject this_CharacterDeclaration_1 = null;



        	enterRule();

        try {
            // InternalMyGames.g:233:2: ( ( (this_IntegerDeclaration_0= ruleIntegerDeclaration | this_CharacterDeclaration_1= ruleCharacterDeclaration ) otherlv_2= ';' ) )
            // InternalMyGames.g:234:2: ( (this_IntegerDeclaration_0= ruleIntegerDeclaration | this_CharacterDeclaration_1= ruleCharacterDeclaration ) otherlv_2= ';' )
            {
            // InternalMyGames.g:234:2: ( (this_IntegerDeclaration_0= ruleIntegerDeclaration | this_CharacterDeclaration_1= ruleCharacterDeclaration ) otherlv_2= ';' )
            // InternalMyGames.g:235:3: (this_IntegerDeclaration_0= ruleIntegerDeclaration | this_CharacterDeclaration_1= ruleCharacterDeclaration ) otherlv_2= ';'
            {
            // InternalMyGames.g:235:3: (this_IntegerDeclaration_0= ruleIntegerDeclaration | this_CharacterDeclaration_1= ruleCharacterDeclaration )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==25) ) {
                alt5=1;
            }
            else if ( ((LA5_0>=20 && LA5_0<=23)) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalMyGames.g:236:4: this_IntegerDeclaration_0= ruleIntegerDeclaration
                    {

                    				newCompositeNode(grammarAccess.getVariableDeclarationAccess().getIntegerDeclarationParserRuleCall_0_0());
                    			
                    pushFollow(FOLLOW_10);
                    this_IntegerDeclaration_0=ruleIntegerDeclaration();

                    state._fsp--;


                    				current = this_IntegerDeclaration_0;
                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;
                case 2 :
                    // InternalMyGames.g:245:4: this_CharacterDeclaration_1= ruleCharacterDeclaration
                    {

                    				newCompositeNode(grammarAccess.getVariableDeclarationAccess().getCharacterDeclarationParserRuleCall_0_1());
                    			
                    pushFollow(FOLLOW_10);
                    this_CharacterDeclaration_1=ruleCharacterDeclaration();

                    state._fsp--;


                    				current = this_CharacterDeclaration_1;
                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            otherlv_2=(Token)match(input,17,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getVariableDeclarationAccess().getSemicolonKeyword_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariableDeclaration"


    // $ANTLR start "entryRuleCharacterDeclaration"
    // InternalMyGames.g:262:1: entryRuleCharacterDeclaration returns [EObject current=null] : iv_ruleCharacterDeclaration= ruleCharacterDeclaration EOF ;
    public final EObject entryRuleCharacterDeclaration() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCharacterDeclaration = null;


        try {
            // InternalMyGames.g:262:61: (iv_ruleCharacterDeclaration= ruleCharacterDeclaration EOF )
            // InternalMyGames.g:263:2: iv_ruleCharacterDeclaration= ruleCharacterDeclaration EOF
            {
             newCompositeNode(grammarAccess.getCharacterDeclarationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCharacterDeclaration=ruleCharacterDeclaration();

            state._fsp--;

             current =iv_ruleCharacterDeclaration; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCharacterDeclaration"


    // $ANTLR start "ruleCharacterDeclaration"
    // InternalMyGames.g:269:1: ruleCharacterDeclaration returns [EObject current=null] : ( ( (lv_Datatype_0_0= ruleCharacterType ) ) ( (lv_name_1_0= RULE_ID ) ) ( (otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ) | ( () otherlv_8= '[' ( (lv_length_9_0= RULE_NUMBER ) ) otherlv_10= ']' ) ) ) ;
    public final EObject ruleCharacterDeclaration() throws RecognitionException {
        EObject current = null;

        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token lv_length_9_0=null;
        Token otherlv_10=null;
        AntlrDatatypeRuleToken lv_Datatype_0_0 = null;

        EObject lv_Formalparameter_3_0 = null;

        EObject lv_Formalparameter_5_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:275:2: ( ( ( (lv_Datatype_0_0= ruleCharacterType ) ) ( (lv_name_1_0= RULE_ID ) ) ( (otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ) | ( () otherlv_8= '[' ( (lv_length_9_0= RULE_NUMBER ) ) otherlv_10= ']' ) ) ) )
            // InternalMyGames.g:276:2: ( ( (lv_Datatype_0_0= ruleCharacterType ) ) ( (lv_name_1_0= RULE_ID ) ) ( (otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ) | ( () otherlv_8= '[' ( (lv_length_9_0= RULE_NUMBER ) ) otherlv_10= ']' ) ) )
            {
            // InternalMyGames.g:276:2: ( ( (lv_Datatype_0_0= ruleCharacterType ) ) ( (lv_name_1_0= RULE_ID ) ) ( (otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ) | ( () otherlv_8= '[' ( (lv_length_9_0= RULE_NUMBER ) ) otherlv_10= ']' ) ) )
            // InternalMyGames.g:277:3: ( (lv_Datatype_0_0= ruleCharacterType ) ) ( (lv_name_1_0= RULE_ID ) ) ( (otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ) | ( () otherlv_8= '[' ( (lv_length_9_0= RULE_NUMBER ) ) otherlv_10= ']' ) )
            {
            // InternalMyGames.g:277:3: ( (lv_Datatype_0_0= ruleCharacterType ) )
            // InternalMyGames.g:278:4: (lv_Datatype_0_0= ruleCharacterType )
            {
            // InternalMyGames.g:278:4: (lv_Datatype_0_0= ruleCharacterType )
            // InternalMyGames.g:279:5: lv_Datatype_0_0= ruleCharacterType
            {

            					newCompositeNode(grammarAccess.getCharacterDeclarationAccess().getDatatypeCharacterTypeParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_3);
            lv_Datatype_0_0=ruleCharacterType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCharacterDeclarationRule());
            					}
            					set(
            						current,
            						"Datatype",
            						lv_Datatype_0_0,
            						"org.xtext.game.mygame.MyGames.CharacterType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyGames.g:296:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalMyGames.g:297:4: (lv_name_1_0= RULE_ID )
            {
            // InternalMyGames.g:297:4: (lv_name_1_0= RULE_ID )
            // InternalMyGames.g:298:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_11); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCharacterDeclarationAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCharacterDeclarationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.xtext.game.mygame.MyGames.ID");
            				

            }


            }

            // InternalMyGames.g:314:3: ( (otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' ) | ( () otherlv_8= '[' ( (lv_length_9_0= RULE_NUMBER ) ) otherlv_10= ']' ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==13) ) {
                alt8=1;
            }
            else if ( (LA8_0==18) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalMyGames.g:315:4: (otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' )
                    {
                    // InternalMyGames.g:315:4: (otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')' )
                    // InternalMyGames.g:316:5: otherlv_2= '(' ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )? otherlv_6= ')'
                    {
                    otherlv_2=(Token)match(input,13,FOLLOW_5); 

                    					newLeafNode(otherlv_2, grammarAccess.getCharacterDeclarationAccess().getLeftParenthesisKeyword_2_0_0());
                    				
                    // InternalMyGames.g:320:5: ( ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )* )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==RULE_ID) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // InternalMyGames.g:321:6: ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) ) (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )*
                            {
                            // InternalMyGames.g:321:6: ( (lv_Formalparameter_3_0= ruleFormalparameterSet ) )
                            // InternalMyGames.g:322:7: (lv_Formalparameter_3_0= ruleFormalparameterSet )
                            {
                            // InternalMyGames.g:322:7: (lv_Formalparameter_3_0= ruleFormalparameterSet )
                            // InternalMyGames.g:323:8: lv_Formalparameter_3_0= ruleFormalparameterSet
                            {

                            								newCompositeNode(grammarAccess.getCharacterDeclarationAccess().getFormalparameterFormalparameterSetParserRuleCall_2_0_1_0_0());
                            							
                            pushFollow(FOLLOW_6);
                            lv_Formalparameter_3_0=ruleFormalparameterSet();

                            state._fsp--;


                            								if (current==null) {
                            									current = createModelElementForParent(grammarAccess.getCharacterDeclarationRule());
                            								}
                            								add(
                            									current,
                            									"Formalparameter",
                            									lv_Formalparameter_3_0,
                            									"org.xtext.game.mygame.MyGames.FormalparameterSet");
                            								afterParserOrEnumRuleCall();
                            							

                            }


                            }

                            // InternalMyGames.g:340:6: (otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) ) )*
                            loop6:
                            do {
                                int alt6=2;
                                int LA6_0 = input.LA(1);

                                if ( (LA6_0==14) ) {
                                    alt6=1;
                                }


                                switch (alt6) {
                            	case 1 :
                            	    // InternalMyGames.g:341:7: otherlv_4= ',' ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) )
                            	    {
                            	    otherlv_4=(Token)match(input,14,FOLLOW_3); 

                            	    							newLeafNode(otherlv_4, grammarAccess.getCharacterDeclarationAccess().getCommaKeyword_2_0_1_1_0());
                            	    						
                            	    // InternalMyGames.g:345:7: ( (lv_Formalparameter_5_0= ruleFormalparameterSet ) )
                            	    // InternalMyGames.g:346:8: (lv_Formalparameter_5_0= ruleFormalparameterSet )
                            	    {
                            	    // InternalMyGames.g:346:8: (lv_Formalparameter_5_0= ruleFormalparameterSet )
                            	    // InternalMyGames.g:347:9: lv_Formalparameter_5_0= ruleFormalparameterSet
                            	    {

                            	    									newCompositeNode(grammarAccess.getCharacterDeclarationAccess().getFormalparameterFormalparameterSetParserRuleCall_2_0_1_1_1_0());
                            	    								
                            	    pushFollow(FOLLOW_6);
                            	    lv_Formalparameter_5_0=ruleFormalparameterSet();

                            	    state._fsp--;


                            	    									if (current==null) {
                            	    										current = createModelElementForParent(grammarAccess.getCharacterDeclarationRule());
                            	    									}
                            	    									add(
                            	    										current,
                            	    										"Formalparameter",
                            	    										lv_Formalparameter_5_0,
                            	    										"org.xtext.game.mygame.MyGames.FormalparameterSet");
                            	    									afterParserOrEnumRuleCall();
                            	    								

                            	    }


                            	    }


                            	    }
                            	    break;

                            	default :
                            	    break loop6;
                                }
                            } while (true);


                            }
                            break;

                    }

                    otherlv_6=(Token)match(input,15,FOLLOW_2); 

                    					newLeafNode(otherlv_6, grammarAccess.getCharacterDeclarationAccess().getRightParenthesisKeyword_2_0_2());
                    				

                    }


                    }
                    break;
                case 2 :
                    // InternalMyGames.g:372:4: ( () otherlv_8= '[' ( (lv_length_9_0= RULE_NUMBER ) ) otherlv_10= ']' )
                    {
                    // InternalMyGames.g:372:4: ( () otherlv_8= '[' ( (lv_length_9_0= RULE_NUMBER ) ) otherlv_10= ']' )
                    // InternalMyGames.g:373:5: () otherlv_8= '[' ( (lv_length_9_0= RULE_NUMBER ) ) otherlv_10= ']'
                    {
                    // InternalMyGames.g:373:5: ()
                    // InternalMyGames.g:374:6: 
                    {

                    						current = forceCreateModelElementAndSet(
                    							grammarAccess.getCharacterDeclarationAccess().getArrayDeclarationVariableAction_2_1_0(),
                    							current);
                    					

                    }

                    otherlv_8=(Token)match(input,18,FOLLOW_12); 

                    					newLeafNode(otherlv_8, grammarAccess.getCharacterDeclarationAccess().getLeftSquareBracketKeyword_2_1_1());
                    				
                    // InternalMyGames.g:384:5: ( (lv_length_9_0= RULE_NUMBER ) )
                    // InternalMyGames.g:385:6: (lv_length_9_0= RULE_NUMBER )
                    {
                    // InternalMyGames.g:385:6: (lv_length_9_0= RULE_NUMBER )
                    // InternalMyGames.g:386:7: lv_length_9_0= RULE_NUMBER
                    {
                    lv_length_9_0=(Token)match(input,RULE_NUMBER,FOLLOW_13); 

                    							newLeafNode(lv_length_9_0, grammarAccess.getCharacterDeclarationAccess().getLengthNUMBERTerminalRuleCall_2_1_2_0());
                    						

                    							if (current==null) {
                    								current = createModelElement(grammarAccess.getCharacterDeclarationRule());
                    							}
                    							setWithLastConsumed(
                    								current,
                    								"length",
                    								lv_length_9_0,
                    								"org.xtext.game.mygame.MyGames.NUMBER");
                    						

                    }


                    }

                    otherlv_10=(Token)match(input,19,FOLLOW_2); 

                    					newLeafNode(otherlv_10, grammarAccess.getCharacterDeclarationAccess().getRightSquareBracketKeyword_2_1_3());
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCharacterDeclaration"


    // $ANTLR start "entryRuleCharacterType"
    // InternalMyGames.g:412:1: entryRuleCharacterType returns [String current=null] : iv_ruleCharacterType= ruleCharacterType EOF ;
    public final String entryRuleCharacterType() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleCharacterType = null;


        try {
            // InternalMyGames.g:412:53: (iv_ruleCharacterType= ruleCharacterType EOF )
            // InternalMyGames.g:413:2: iv_ruleCharacterType= ruleCharacterType EOF
            {
             newCompositeNode(grammarAccess.getCharacterTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCharacterType=ruleCharacterType();

            state._fsp--;

             current =iv_ruleCharacterType.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCharacterType"


    // $ANTLR start "ruleCharacterType"
    // InternalMyGames.g:419:1: ruleCharacterType returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'Player' | kw= 'Obstacle' | kw= 'GameProps' | kw= 'Destination' ) ;
    public final AntlrDatatypeRuleToken ruleCharacterType() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyGames.g:425:2: ( (kw= 'Player' | kw= 'Obstacle' | kw= 'GameProps' | kw= 'Destination' ) )
            // InternalMyGames.g:426:2: (kw= 'Player' | kw= 'Obstacle' | kw= 'GameProps' | kw= 'Destination' )
            {
            // InternalMyGames.g:426:2: (kw= 'Player' | kw= 'Obstacle' | kw= 'GameProps' | kw= 'Destination' )
            int alt9=4;
            switch ( input.LA(1) ) {
            case 20:
                {
                alt9=1;
                }
                break;
            case 21:
                {
                alt9=2;
                }
                break;
            case 22:
                {
                alt9=3;
                }
                break;
            case 23:
                {
                alt9=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalMyGames.g:427:3: kw= 'Player'
                    {
                    kw=(Token)match(input,20,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getCharacterTypeAccess().getPlayerKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMyGames.g:433:3: kw= 'Obstacle'
                    {
                    kw=(Token)match(input,21,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getCharacterTypeAccess().getObstacleKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalMyGames.g:439:3: kw= 'GameProps'
                    {
                    kw=(Token)match(input,22,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getCharacterTypeAccess().getGamePropsKeyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalMyGames.g:445:3: kw= 'Destination'
                    {
                    kw=(Token)match(input,23,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getCharacterTypeAccess().getDestinationKeyword_3());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCharacterType"


    // $ANTLR start "entryRuleFormalparameterSet"
    // InternalMyGames.g:454:1: entryRuleFormalparameterSet returns [EObject current=null] : iv_ruleFormalparameterSet= ruleFormalparameterSet EOF ;
    public final EObject entryRuleFormalparameterSet() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFormalparameterSet = null;


        try {
            // InternalMyGames.g:454:59: (iv_ruleFormalparameterSet= ruleFormalparameterSet EOF )
            // InternalMyGames.g:455:2: iv_ruleFormalparameterSet= ruleFormalparameterSet EOF
            {
             newCompositeNode(grammarAccess.getFormalparameterSetRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFormalparameterSet=ruleFormalparameterSet();

            state._fsp--;

             current =iv_ruleFormalparameterSet; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFormalparameterSet"


    // $ANTLR start "ruleFormalparameterSet"
    // InternalMyGames.g:461:1: ruleFormalparameterSet returns [EObject current=null] : ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= ruleExpression ) ) ) ;
    public final EObject ruleFormalparameterSet() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        EObject lv_value_2_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:467:2: ( ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= ruleExpression ) ) ) )
            // InternalMyGames.g:468:2: ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= ruleExpression ) ) )
            {
            // InternalMyGames.g:468:2: ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= ruleExpression ) ) )
            // InternalMyGames.g:469:3: ( (lv_name_0_0= RULE_ID ) ) otherlv_1= '=' ( (lv_value_2_0= ruleExpression ) )
            {
            // InternalMyGames.g:469:3: ( (lv_name_0_0= RULE_ID ) )
            // InternalMyGames.g:470:4: (lv_name_0_0= RULE_ID )
            {
            // InternalMyGames.g:470:4: (lv_name_0_0= RULE_ID )
            // InternalMyGames.g:471:5: lv_name_0_0= RULE_ID
            {
            lv_name_0_0=(Token)match(input,RULE_ID,FOLLOW_14); 

            					newLeafNode(lv_name_0_0, grammarAccess.getFormalparameterSetAccess().getNameIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFormalparameterSetRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_0_0,
            						"org.xtext.game.mygame.MyGames.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,24,FOLLOW_15); 

            			newLeafNode(otherlv_1, grammarAccess.getFormalparameterSetAccess().getEqualsSignKeyword_1());
            		
            // InternalMyGames.g:491:3: ( (lv_value_2_0= ruleExpression ) )
            // InternalMyGames.g:492:4: (lv_value_2_0= ruleExpression )
            {
            // InternalMyGames.g:492:4: (lv_value_2_0= ruleExpression )
            // InternalMyGames.g:493:5: lv_value_2_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getFormalparameterSetAccess().getValueExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_value_2_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFormalparameterSetRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_2_0,
            						"org.xtext.game.mygame.MyGames.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFormalparameterSet"


    // $ANTLR start "entryRuleIntegerDeclaration"
    // InternalMyGames.g:514:1: entryRuleIntegerDeclaration returns [EObject current=null] : iv_ruleIntegerDeclaration= ruleIntegerDeclaration EOF ;
    public final EObject entryRuleIntegerDeclaration() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIntegerDeclaration = null;


        try {
            // InternalMyGames.g:514:59: (iv_ruleIntegerDeclaration= ruleIntegerDeclaration EOF )
            // InternalMyGames.g:515:2: iv_ruleIntegerDeclaration= ruleIntegerDeclaration EOF
            {
             newCompositeNode(grammarAccess.getIntegerDeclarationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIntegerDeclaration=ruleIntegerDeclaration();

            state._fsp--;

             current =iv_ruleIntegerDeclaration; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIntegerDeclaration"


    // $ANTLR start "ruleIntegerDeclaration"
    // InternalMyGames.g:521:1: ruleIntegerDeclaration returns [EObject current=null] : (otherlv_0= 'Var' ( (lv_Datatype_1_0= 'int' ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_init_3_0= ruleVariableInitiation ) )? ) ;
    public final EObject ruleIntegerDeclaration() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_Datatype_1_0=null;
        Token lv_name_2_0=null;
        EObject lv_init_3_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:527:2: ( (otherlv_0= 'Var' ( (lv_Datatype_1_0= 'int' ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_init_3_0= ruleVariableInitiation ) )? ) )
            // InternalMyGames.g:528:2: (otherlv_0= 'Var' ( (lv_Datatype_1_0= 'int' ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_init_3_0= ruleVariableInitiation ) )? )
            {
            // InternalMyGames.g:528:2: (otherlv_0= 'Var' ( (lv_Datatype_1_0= 'int' ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_init_3_0= ruleVariableInitiation ) )? )
            // InternalMyGames.g:529:3: otherlv_0= 'Var' ( (lv_Datatype_1_0= 'int' ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_init_3_0= ruleVariableInitiation ) )?
            {
            otherlv_0=(Token)match(input,25,FOLLOW_16); 

            			newLeafNode(otherlv_0, grammarAccess.getIntegerDeclarationAccess().getVarKeyword_0());
            		
            // InternalMyGames.g:533:3: ( (lv_Datatype_1_0= 'int' ) )
            // InternalMyGames.g:534:4: (lv_Datatype_1_0= 'int' )
            {
            // InternalMyGames.g:534:4: (lv_Datatype_1_0= 'int' )
            // InternalMyGames.g:535:5: lv_Datatype_1_0= 'int'
            {
            lv_Datatype_1_0=(Token)match(input,26,FOLLOW_3); 

            					newLeafNode(lv_Datatype_1_0, grammarAccess.getIntegerDeclarationAccess().getDatatypeIntKeyword_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getIntegerDeclarationRule());
            					}
            					setWithLastConsumed(current, "Datatype", lv_Datatype_1_0, "int");
            				

            }


            }

            // InternalMyGames.g:547:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalMyGames.g:548:4: (lv_name_2_0= RULE_ID )
            {
            // InternalMyGames.g:548:4: (lv_name_2_0= RULE_ID )
            // InternalMyGames.g:549:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_17); 

            					newLeafNode(lv_name_2_0, grammarAccess.getIntegerDeclarationAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getIntegerDeclarationRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.xtext.game.mygame.MyGames.ID");
            				

            }


            }

            // InternalMyGames.g:565:3: ( (lv_init_3_0= ruleVariableInitiation ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==24) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalMyGames.g:566:4: (lv_init_3_0= ruleVariableInitiation )
                    {
                    // InternalMyGames.g:566:4: (lv_init_3_0= ruleVariableInitiation )
                    // InternalMyGames.g:567:5: lv_init_3_0= ruleVariableInitiation
                    {

                    					newCompositeNode(grammarAccess.getIntegerDeclarationAccess().getInitVariableInitiationParserRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_init_3_0=ruleVariableInitiation();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getIntegerDeclarationRule());
                    					}
                    					set(
                    						current,
                    						"init",
                    						lv_init_3_0,
                    						"org.xtext.game.mygame.MyGames.VariableInitiation");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIntegerDeclaration"


    // $ANTLR start "entryRuleVariableInitiation"
    // InternalMyGames.g:588:1: entryRuleVariableInitiation returns [EObject current=null] : iv_ruleVariableInitiation= ruleVariableInitiation EOF ;
    public final EObject entryRuleVariableInitiation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariableInitiation = null;


        try {
            // InternalMyGames.g:588:59: (iv_ruleVariableInitiation= ruleVariableInitiation EOF )
            // InternalMyGames.g:589:2: iv_ruleVariableInitiation= ruleVariableInitiation EOF
            {
             newCompositeNode(grammarAccess.getVariableInitiationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariableInitiation=ruleVariableInitiation();

            state._fsp--;

             current =iv_ruleVariableInitiation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariableInitiation"


    // $ANTLR start "ruleVariableInitiation"
    // InternalMyGames.g:595:1: ruleVariableInitiation returns [EObject current=null] : (otherlv_0= '=' this_Expression_1= ruleExpression ) ;
    public final EObject ruleVariableInitiation() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_Expression_1 = null;



        	enterRule();

        try {
            // InternalMyGames.g:601:2: ( (otherlv_0= '=' this_Expression_1= ruleExpression ) )
            // InternalMyGames.g:602:2: (otherlv_0= '=' this_Expression_1= ruleExpression )
            {
            // InternalMyGames.g:602:2: (otherlv_0= '=' this_Expression_1= ruleExpression )
            // InternalMyGames.g:603:3: otherlv_0= '=' this_Expression_1= ruleExpression
            {
            otherlv_0=(Token)match(input,24,FOLLOW_15); 

            			newLeafNode(otherlv_0, grammarAccess.getVariableInitiationAccess().getEqualsSignKeyword_0());
            		

            			newCompositeNode(grammarAccess.getVariableInitiationAccess().getExpressionParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_Expression_1=ruleExpression();

            state._fsp--;


            			current = this_Expression_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariableInitiation"


    // $ANTLR start "entryRuleKeyPressEventsBlock"
    // InternalMyGames.g:619:1: entryRuleKeyPressEventsBlock returns [EObject current=null] : iv_ruleKeyPressEventsBlock= ruleKeyPressEventsBlock EOF ;
    public final EObject entryRuleKeyPressEventsBlock() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleKeyPressEventsBlock = null;


        try {
            // InternalMyGames.g:619:60: (iv_ruleKeyPressEventsBlock= ruleKeyPressEventsBlock EOF )
            // InternalMyGames.g:620:2: iv_ruleKeyPressEventsBlock= ruleKeyPressEventsBlock EOF
            {
             newCompositeNode(grammarAccess.getKeyPressEventsBlockRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleKeyPressEventsBlock=ruleKeyPressEventsBlock();

            state._fsp--;

             current =iv_ruleKeyPressEventsBlock; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleKeyPressEventsBlock"


    // $ANTLR start "ruleKeyPressEventsBlock"
    // InternalMyGames.g:626:1: ruleKeyPressEventsBlock returns [EObject current=null] : (otherlv_0= 'Trigger' ( (lv_keyschoice_1_0= ruleKeys ) ) ( (lv_triggerstatements_2_0= ruleNormalStatementBlock ) ) ) ;
    public final EObject ruleKeyPressEventsBlock() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_keyschoice_1_0 = null;

        EObject lv_triggerstatements_2_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:632:2: ( (otherlv_0= 'Trigger' ( (lv_keyschoice_1_0= ruleKeys ) ) ( (lv_triggerstatements_2_0= ruleNormalStatementBlock ) ) ) )
            // InternalMyGames.g:633:2: (otherlv_0= 'Trigger' ( (lv_keyschoice_1_0= ruleKeys ) ) ( (lv_triggerstatements_2_0= ruleNormalStatementBlock ) ) )
            {
            // InternalMyGames.g:633:2: (otherlv_0= 'Trigger' ( (lv_keyschoice_1_0= ruleKeys ) ) ( (lv_triggerstatements_2_0= ruleNormalStatementBlock ) ) )
            // InternalMyGames.g:634:3: otherlv_0= 'Trigger' ( (lv_keyschoice_1_0= ruleKeys ) ) ( (lv_triggerstatements_2_0= ruleNormalStatementBlock ) )
            {
            otherlv_0=(Token)match(input,27,FOLLOW_18); 

            			newLeafNode(otherlv_0, grammarAccess.getKeyPressEventsBlockAccess().getTriggerKeyword_0());
            		
            // InternalMyGames.g:638:3: ( (lv_keyschoice_1_0= ruleKeys ) )
            // InternalMyGames.g:639:4: (lv_keyschoice_1_0= ruleKeys )
            {
            // InternalMyGames.g:639:4: (lv_keyschoice_1_0= ruleKeys )
            // InternalMyGames.g:640:5: lv_keyschoice_1_0= ruleKeys
            {

            					newCompositeNode(grammarAccess.getKeyPressEventsBlockAccess().getKeyschoiceKeysParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_8);
            lv_keyschoice_1_0=ruleKeys();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getKeyPressEventsBlockRule());
            					}
            					set(
            						current,
            						"keyschoice",
            						lv_keyschoice_1_0,
            						"org.xtext.game.mygame.MyGames.Keys");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyGames.g:657:3: ( (lv_triggerstatements_2_0= ruleNormalStatementBlock ) )
            // InternalMyGames.g:658:4: (lv_triggerstatements_2_0= ruleNormalStatementBlock )
            {
            // InternalMyGames.g:658:4: (lv_triggerstatements_2_0= ruleNormalStatementBlock )
            // InternalMyGames.g:659:5: lv_triggerstatements_2_0= ruleNormalStatementBlock
            {

            					newCompositeNode(grammarAccess.getKeyPressEventsBlockAccess().getTriggerstatementsNormalStatementBlockParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_triggerstatements_2_0=ruleNormalStatementBlock();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getKeyPressEventsBlockRule());
            					}
            					set(
            						current,
            						"triggerstatements",
            						lv_triggerstatements_2_0,
            						"org.xtext.game.mygame.MyGames.NormalStatementBlock");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleKeyPressEventsBlock"


    // $ANTLR start "entryRuleKeys"
    // InternalMyGames.g:680:1: entryRuleKeys returns [String current=null] : iv_ruleKeys= ruleKeys EOF ;
    public final String entryRuleKeys() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleKeys = null;


        try {
            // InternalMyGames.g:680:44: (iv_ruleKeys= ruleKeys EOF )
            // InternalMyGames.g:681:2: iv_ruleKeys= ruleKeys EOF
            {
             newCompositeNode(grammarAccess.getKeysRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleKeys=ruleKeys();

            state._fsp--;

             current =iv_ruleKeys.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleKeys"


    // $ANTLR start "ruleKeys"
    // InternalMyGames.g:687:1: ruleKeys returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'UP' | kw= 'DOWN' | kw= 'LEFT' | kw= 'RIGHT' ) ;
    public final AntlrDatatypeRuleToken ruleKeys() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyGames.g:693:2: ( (kw= 'UP' | kw= 'DOWN' | kw= 'LEFT' | kw= 'RIGHT' ) )
            // InternalMyGames.g:694:2: (kw= 'UP' | kw= 'DOWN' | kw= 'LEFT' | kw= 'RIGHT' )
            {
            // InternalMyGames.g:694:2: (kw= 'UP' | kw= 'DOWN' | kw= 'LEFT' | kw= 'RIGHT' )
            int alt11=4;
            switch ( input.LA(1) ) {
            case 28:
                {
                alt11=1;
                }
                break;
            case 29:
                {
                alt11=2;
                }
                break;
            case 30:
                {
                alt11=3;
                }
                break;
            case 31:
                {
                alt11=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // InternalMyGames.g:695:3: kw= 'UP'
                    {
                    kw=(Token)match(input,28,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getKeysAccess().getUPKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMyGames.g:701:3: kw= 'DOWN'
                    {
                    kw=(Token)match(input,29,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getKeysAccess().getDOWNKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalMyGames.g:707:3: kw= 'LEFT'
                    {
                    kw=(Token)match(input,30,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getKeysAccess().getLEFTKeyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalMyGames.g:713:3: kw= 'RIGHT'
                    {
                    kw=(Token)match(input,31,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getKeysAccess().getRIGHTKeyword_3());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleKeys"


    // $ANTLR start "entryRuleNormalStatementBlock"
    // InternalMyGames.g:722:1: entryRuleNormalStatementBlock returns [EObject current=null] : iv_ruleNormalStatementBlock= ruleNormalStatementBlock EOF ;
    public final EObject entryRuleNormalStatementBlock() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNormalStatementBlock = null;


        try {
            // InternalMyGames.g:722:61: (iv_ruleNormalStatementBlock= ruleNormalStatementBlock EOF )
            // InternalMyGames.g:723:2: iv_ruleNormalStatementBlock= ruleNormalStatementBlock EOF
            {
             newCompositeNode(grammarAccess.getNormalStatementBlockRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNormalStatementBlock=ruleNormalStatementBlock();

            state._fsp--;

             current =iv_ruleNormalStatementBlock; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNormalStatementBlock"


    // $ANTLR start "ruleNormalStatementBlock"
    // InternalMyGames.g:729:1: ruleNormalStatementBlock returns [EObject current=null] : ( () otherlv_1= '{' ( (lv_normalstatements_2_0= ruleNormalStatement ) )* otherlv_3= '}' ) ;
    public final EObject ruleNormalStatementBlock() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_normalstatements_2_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:735:2: ( ( () otherlv_1= '{' ( (lv_normalstatements_2_0= ruleNormalStatement ) )* otherlv_3= '}' ) )
            // InternalMyGames.g:736:2: ( () otherlv_1= '{' ( (lv_normalstatements_2_0= ruleNormalStatement ) )* otherlv_3= '}' )
            {
            // InternalMyGames.g:736:2: ( () otherlv_1= '{' ( (lv_normalstatements_2_0= ruleNormalStatement ) )* otherlv_3= '}' )
            // InternalMyGames.g:737:3: () otherlv_1= '{' ( (lv_normalstatements_2_0= ruleNormalStatement ) )* otherlv_3= '}'
            {
            // InternalMyGames.g:737:3: ()
            // InternalMyGames.g:738:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getNormalStatementBlockAccess().getNormalStatementBlockAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,32,FOLLOW_19); 

            			newLeafNode(otherlv_1, grammarAccess.getNormalStatementBlockAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalMyGames.g:748:3: ( (lv_normalstatements_2_0= ruleNormalStatement ) )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==RULE_ID||LA12_0==35||LA12_0==37) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalMyGames.g:749:4: (lv_normalstatements_2_0= ruleNormalStatement )
            	    {
            	    // InternalMyGames.g:749:4: (lv_normalstatements_2_0= ruleNormalStatement )
            	    // InternalMyGames.g:750:5: lv_normalstatements_2_0= ruleNormalStatement
            	    {

            	    					newCompositeNode(grammarAccess.getNormalStatementBlockAccess().getNormalstatementsNormalStatementParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_19);
            	    lv_normalstatements_2_0=ruleNormalStatement();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getNormalStatementBlockRule());
            	    					}
            	    					add(
            	    						current,
            	    						"normalstatements",
            	    						lv_normalstatements_2_0,
            	    						"org.xtext.game.mygame.MyGames.NormalStatement");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

            otherlv_3=(Token)match(input,33,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getNormalStatementBlockAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNormalStatementBlock"


    // $ANTLR start "entryRuleNormalStatement"
    // InternalMyGames.g:775:1: entryRuleNormalStatement returns [EObject current=null] : iv_ruleNormalStatement= ruleNormalStatement EOF ;
    public final EObject entryRuleNormalStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNormalStatement = null;


        try {
            // InternalMyGames.g:775:56: (iv_ruleNormalStatement= ruleNormalStatement EOF )
            // InternalMyGames.g:776:2: iv_ruleNormalStatement= ruleNormalStatement EOF
            {
             newCompositeNode(grammarAccess.getNormalStatementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNormalStatement=ruleNormalStatement();

            state._fsp--;

             current =iv_ruleNormalStatement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNormalStatement"


    // $ANTLR start "ruleNormalStatement"
    // InternalMyGames.g:782:1: ruleNormalStatement returns [EObject current=null] : (this_IfStatement_0= ruleIfStatement | this_ForStatement_1= ruleForStatement | (this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';' ) ) ;
    public final EObject ruleNormalStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_3=null;
        EObject this_IfStatement_0 = null;

        EObject this_ForStatement_1 = null;

        EObject this_AssignmentStatement_2 = null;



        	enterRule();

        try {
            // InternalMyGames.g:788:2: ( (this_IfStatement_0= ruleIfStatement | this_ForStatement_1= ruleForStatement | (this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';' ) ) )
            // InternalMyGames.g:789:2: (this_IfStatement_0= ruleIfStatement | this_ForStatement_1= ruleForStatement | (this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';' ) )
            {
            // InternalMyGames.g:789:2: (this_IfStatement_0= ruleIfStatement | this_ForStatement_1= ruleForStatement | (this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';' ) )
            int alt13=3;
            switch ( input.LA(1) ) {
            case 35:
                {
                alt13=1;
                }
                break;
            case 37:
                {
                alt13=2;
                }
                break;
            case RULE_ID:
                {
                alt13=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }

            switch (alt13) {
                case 1 :
                    // InternalMyGames.g:790:3: this_IfStatement_0= ruleIfStatement
                    {

                    			newCompositeNode(grammarAccess.getNormalStatementAccess().getIfStatementParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_IfStatement_0=ruleIfStatement();

                    state._fsp--;


                    			current = this_IfStatement_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMyGames.g:799:3: this_ForStatement_1= ruleForStatement
                    {

                    			newCompositeNode(grammarAccess.getNormalStatementAccess().getForStatementParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_ForStatement_1=ruleForStatement();

                    state._fsp--;


                    			current = this_ForStatement_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMyGames.g:808:3: (this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';' )
                    {
                    // InternalMyGames.g:808:3: (this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';' )
                    // InternalMyGames.g:809:4: this_AssignmentStatement_2= ruleAssignmentStatement otherlv_3= ';'
                    {

                    				newCompositeNode(grammarAccess.getNormalStatementAccess().getAssignmentStatementParserRuleCall_2_0());
                    			
                    pushFollow(FOLLOW_10);
                    this_AssignmentStatement_2=ruleAssignmentStatement();

                    state._fsp--;


                    				current = this_AssignmentStatement_2;
                    				afterParserOrEnumRuleCall();
                    			
                    otherlv_3=(Token)match(input,17,FOLLOW_2); 

                    				newLeafNode(otherlv_3, grammarAccess.getNormalStatementAccess().getSemicolonKeyword_2_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNormalStatement"


    // $ANTLR start "entryRuleAssignmentStatement"
    // InternalMyGames.g:826:1: entryRuleAssignmentStatement returns [EObject current=null] : iv_ruleAssignmentStatement= ruleAssignmentStatement EOF ;
    public final EObject entryRuleAssignmentStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAssignmentStatement = null;


        try {
            // InternalMyGames.g:826:60: (iv_ruleAssignmentStatement= ruleAssignmentStatement EOF )
            // InternalMyGames.g:827:2: iv_ruleAssignmentStatement= ruleAssignmentStatement EOF
            {
             newCompositeNode(grammarAccess.getAssignmentStatementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAssignmentStatement=ruleAssignmentStatement();

            state._fsp--;

             current =iv_ruleAssignmentStatement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAssignmentStatement"


    // $ANTLR start "ruleAssignmentStatement"
    // InternalMyGames.g:833:1: ruleAssignmentStatement returns [EObject current=null] : ( ( (lv_variable_0_0= ruleVaraible ) ) otherlv_1= '=' ( (lv_expression_2_0= ruleExpression ) ) ) ;
    public final EObject ruleAssignmentStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_variable_0_0 = null;

        EObject lv_expression_2_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:839:2: ( ( ( (lv_variable_0_0= ruleVaraible ) ) otherlv_1= '=' ( (lv_expression_2_0= ruleExpression ) ) ) )
            // InternalMyGames.g:840:2: ( ( (lv_variable_0_0= ruleVaraible ) ) otherlv_1= '=' ( (lv_expression_2_0= ruleExpression ) ) )
            {
            // InternalMyGames.g:840:2: ( ( (lv_variable_0_0= ruleVaraible ) ) otherlv_1= '=' ( (lv_expression_2_0= ruleExpression ) ) )
            // InternalMyGames.g:841:3: ( (lv_variable_0_0= ruleVaraible ) ) otherlv_1= '=' ( (lv_expression_2_0= ruleExpression ) )
            {
            // InternalMyGames.g:841:3: ( (lv_variable_0_0= ruleVaraible ) )
            // InternalMyGames.g:842:4: (lv_variable_0_0= ruleVaraible )
            {
            // InternalMyGames.g:842:4: (lv_variable_0_0= ruleVaraible )
            // InternalMyGames.g:843:5: lv_variable_0_0= ruleVaraible
            {

            					newCompositeNode(grammarAccess.getAssignmentStatementAccess().getVariableVaraibleParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_14);
            lv_variable_0_0=ruleVaraible();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAssignmentStatementRule());
            					}
            					set(
            						current,
            						"variable",
            						lv_variable_0_0,
            						"org.xtext.game.mygame.MyGames.Varaible");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_1=(Token)match(input,24,FOLLOW_15); 

            			newLeafNode(otherlv_1, grammarAccess.getAssignmentStatementAccess().getEqualsSignKeyword_1());
            		
            // InternalMyGames.g:864:3: ( (lv_expression_2_0= ruleExpression ) )
            // InternalMyGames.g:865:4: (lv_expression_2_0= ruleExpression )
            {
            // InternalMyGames.g:865:4: (lv_expression_2_0= ruleExpression )
            // InternalMyGames.g:866:5: lv_expression_2_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getAssignmentStatementAccess().getExpressionExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_expression_2_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAssignmentStatementRule());
            					}
            					set(
            						current,
            						"expression",
            						lv_expression_2_0,
            						"org.xtext.game.mygame.MyGames.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAssignmentStatement"


    // $ANTLR start "entryRuleVaraible"
    // InternalMyGames.g:887:1: entryRuleVaraible returns [EObject current=null] : iv_ruleVaraible= ruleVaraible EOF ;
    public final EObject entryRuleVaraible() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVaraible = null;


        try {
            // InternalMyGames.g:887:49: (iv_ruleVaraible= ruleVaraible EOF )
            // InternalMyGames.g:888:2: iv_ruleVaraible= ruleVaraible EOF
            {
             newCompositeNode(grammarAccess.getVaraibleRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVaraible=ruleVaraible();

            state._fsp--;

             current =iv_ruleVaraible; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVaraible"


    // $ANTLR start "ruleVaraible"
    // InternalMyGames.g:894:1: ruleVaraible returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) ( () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']' )? ( () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) ) )? ) ;
    public final EObject ruleVaraible() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token lv_attributes_7_0=null;
        EObject lv_index_3_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:900:2: ( ( ( (otherlv_0= RULE_ID ) ) ( () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']' )? ( () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) ) )? ) )
            // InternalMyGames.g:901:2: ( ( (otherlv_0= RULE_ID ) ) ( () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']' )? ( () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) ) )? )
            {
            // InternalMyGames.g:901:2: ( ( (otherlv_0= RULE_ID ) ) ( () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']' )? ( () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) ) )? )
            // InternalMyGames.g:902:3: ( (otherlv_0= RULE_ID ) ) ( () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']' )? ( () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) ) )?
            {
            // InternalMyGames.g:902:3: ( (otherlv_0= RULE_ID ) )
            // InternalMyGames.g:903:4: (otherlv_0= RULE_ID )
            {
            // InternalMyGames.g:903:4: (otherlv_0= RULE_ID )
            // InternalMyGames.g:904:5: otherlv_0= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVaraibleRule());
            					}
            				
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_20); 

            					newLeafNode(otherlv_0, grammarAccess.getVaraibleAccess().getIdAllDeclarationsCrossReference_0_0());
            				

            }


            }

            // InternalMyGames.g:915:3: ( () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']' )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==18) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalMyGames.g:916:4: () otherlv_2= '[' ( (lv_index_3_0= ruleExpression ) ) otherlv_4= ']'
                    {
                    // InternalMyGames.g:916:4: ()
                    // InternalMyGames.g:917:5: 
                    {

                    					current = forceCreateModelElementAndSet(
                    						grammarAccess.getVaraibleAccess().getCharacterMemberVariableAction_1_0(),
                    						current);
                    				

                    }

                    otherlv_2=(Token)match(input,18,FOLLOW_15); 

                    				newLeafNode(otherlv_2, grammarAccess.getVaraibleAccess().getLeftSquareBracketKeyword_1_1());
                    			
                    // InternalMyGames.g:927:4: ( (lv_index_3_0= ruleExpression ) )
                    // InternalMyGames.g:928:5: (lv_index_3_0= ruleExpression )
                    {
                    // InternalMyGames.g:928:5: (lv_index_3_0= ruleExpression )
                    // InternalMyGames.g:929:6: lv_index_3_0= ruleExpression
                    {

                    						newCompositeNode(grammarAccess.getVaraibleAccess().getIndexExpressionParserRuleCall_1_2_0());
                    					
                    pushFollow(FOLLOW_13);
                    lv_index_3_0=ruleExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getVaraibleRule());
                    						}
                    						set(
                    							current,
                    							"index",
                    							lv_index_3_0,
                    							"org.xtext.game.mygame.MyGames.Expression");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    otherlv_4=(Token)match(input,19,FOLLOW_21); 

                    				newLeafNode(otherlv_4, grammarAccess.getVaraibleAccess().getRightSquareBracketKeyword_1_3());
                    			

                    }
                    break;

            }

            // InternalMyGames.g:951:3: ( () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==34) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalMyGames.g:952:4: () otherlv_6= '.' ( (lv_attributes_7_0= RULE_ID ) )
                    {
                    // InternalMyGames.g:952:4: ()
                    // InternalMyGames.g:953:5: 
                    {

                    					current = forceCreateModelElementAndSet(
                    						grammarAccess.getVaraibleAccess().getCharacterAttributeVariableAction_2_0(),
                    						current);
                    				

                    }

                    otherlv_6=(Token)match(input,34,FOLLOW_3); 

                    				newLeafNode(otherlv_6, grammarAccess.getVaraibleAccess().getFullStopKeyword_2_1());
                    			
                    // InternalMyGames.g:963:4: ( (lv_attributes_7_0= RULE_ID ) )
                    // InternalMyGames.g:964:5: (lv_attributes_7_0= RULE_ID )
                    {
                    // InternalMyGames.g:964:5: (lv_attributes_7_0= RULE_ID )
                    // InternalMyGames.g:965:6: lv_attributes_7_0= RULE_ID
                    {
                    lv_attributes_7_0=(Token)match(input,RULE_ID,FOLLOW_2); 

                    						newLeafNode(lv_attributes_7_0, grammarAccess.getVaraibleAccess().getAttributesIDTerminalRuleCall_2_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVaraibleRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"attributes",
                    							lv_attributes_7_0,
                    							"org.xtext.game.mygame.MyGames.ID");
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVaraible"


    // $ANTLR start "entryRuleIfStatement"
    // InternalMyGames.g:986:1: entryRuleIfStatement returns [EObject current=null] : iv_ruleIfStatement= ruleIfStatement EOF ;
    public final EObject entryRuleIfStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIfStatement = null;


        try {
            // InternalMyGames.g:986:52: (iv_ruleIfStatement= ruleIfStatement EOF )
            // InternalMyGames.g:987:2: iv_ruleIfStatement= ruleIfStatement EOF
            {
             newCompositeNode(grammarAccess.getIfStatementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIfStatement=ruleIfStatement();

            state._fsp--;

             current =iv_ruleIfStatement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIfStatement"


    // $ANTLR start "ruleIfStatement"
    // InternalMyGames.g:993:1: ruleIfStatement returns [EObject current=null] : (otherlv_0= 'if' otherlv_1= '(' ( (lv_condition_2_0= ruleExpression ) ) otherlv_3= ')' ( (lv_thenstatements_4_0= ruleNormalStatementBlock ) ) (otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) ) )? ) ;
    public final EObject ruleIfStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject lv_condition_2_0 = null;

        EObject lv_thenstatements_4_0 = null;

        EObject lv_elsestatements_6_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:999:2: ( (otherlv_0= 'if' otherlv_1= '(' ( (lv_condition_2_0= ruleExpression ) ) otherlv_3= ')' ( (lv_thenstatements_4_0= ruleNormalStatementBlock ) ) (otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) ) )? ) )
            // InternalMyGames.g:1000:2: (otherlv_0= 'if' otherlv_1= '(' ( (lv_condition_2_0= ruleExpression ) ) otherlv_3= ')' ( (lv_thenstatements_4_0= ruleNormalStatementBlock ) ) (otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) ) )? )
            {
            // InternalMyGames.g:1000:2: (otherlv_0= 'if' otherlv_1= '(' ( (lv_condition_2_0= ruleExpression ) ) otherlv_3= ')' ( (lv_thenstatements_4_0= ruleNormalStatementBlock ) ) (otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) ) )? )
            // InternalMyGames.g:1001:3: otherlv_0= 'if' otherlv_1= '(' ( (lv_condition_2_0= ruleExpression ) ) otherlv_3= ')' ( (lv_thenstatements_4_0= ruleNormalStatementBlock ) ) (otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) ) )?
            {
            otherlv_0=(Token)match(input,35,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getIfStatementAccess().getIfKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_15); 

            			newLeafNode(otherlv_1, grammarAccess.getIfStatementAccess().getLeftParenthesisKeyword_1());
            		
            // InternalMyGames.g:1009:3: ( (lv_condition_2_0= ruleExpression ) )
            // InternalMyGames.g:1010:4: (lv_condition_2_0= ruleExpression )
            {
            // InternalMyGames.g:1010:4: (lv_condition_2_0= ruleExpression )
            // InternalMyGames.g:1011:5: lv_condition_2_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getIfStatementAccess().getConditionExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_22);
            lv_condition_2_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIfStatementRule());
            					}
            					set(
            						current,
            						"condition",
            						lv_condition_2_0,
            						"org.xtext.game.mygame.MyGames.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,15,FOLLOW_8); 

            			newLeafNode(otherlv_3, grammarAccess.getIfStatementAccess().getRightParenthesisKeyword_3());
            		
            // InternalMyGames.g:1032:3: ( (lv_thenstatements_4_0= ruleNormalStatementBlock ) )
            // InternalMyGames.g:1033:4: (lv_thenstatements_4_0= ruleNormalStatementBlock )
            {
            // InternalMyGames.g:1033:4: (lv_thenstatements_4_0= ruleNormalStatementBlock )
            // InternalMyGames.g:1034:5: lv_thenstatements_4_0= ruleNormalStatementBlock
            {

            					newCompositeNode(grammarAccess.getIfStatementAccess().getThenstatementsNormalStatementBlockParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_23);
            lv_thenstatements_4_0=ruleNormalStatementBlock();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIfStatementRule());
            					}
            					set(
            						current,
            						"thenstatements",
            						lv_thenstatements_4_0,
            						"org.xtext.game.mygame.MyGames.NormalStatementBlock");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyGames.g:1051:3: (otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==36) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalMyGames.g:1052:4: otherlv_5= 'else' ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) )
                    {
                    otherlv_5=(Token)match(input,36,FOLLOW_8); 

                    				newLeafNode(otherlv_5, grammarAccess.getIfStatementAccess().getElseKeyword_5_0());
                    			
                    // InternalMyGames.g:1056:4: ( (lv_elsestatements_6_0= ruleNormalStatementBlock ) )
                    // InternalMyGames.g:1057:5: (lv_elsestatements_6_0= ruleNormalStatementBlock )
                    {
                    // InternalMyGames.g:1057:5: (lv_elsestatements_6_0= ruleNormalStatementBlock )
                    // InternalMyGames.g:1058:6: lv_elsestatements_6_0= ruleNormalStatementBlock
                    {

                    						newCompositeNode(grammarAccess.getIfStatementAccess().getElsestatementsNormalStatementBlockParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_elsestatements_6_0=ruleNormalStatementBlock();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getIfStatementRule());
                    						}
                    						set(
                    							current,
                    							"elsestatements",
                    							lv_elsestatements_6_0,
                    							"org.xtext.game.mygame.MyGames.NormalStatementBlock");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIfStatement"


    // $ANTLR start "entryRuleForStatement"
    // InternalMyGames.g:1080:1: entryRuleForStatement returns [EObject current=null] : iv_ruleForStatement= ruleForStatement EOF ;
    public final EObject entryRuleForStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleForStatement = null;


        try {
            // InternalMyGames.g:1080:53: (iv_ruleForStatement= ruleForStatement EOF )
            // InternalMyGames.g:1081:2: iv_ruleForStatement= ruleForStatement EOF
            {
             newCompositeNode(grammarAccess.getForStatementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleForStatement=ruleForStatement();

            state._fsp--;

             current =iv_ruleForStatement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleForStatement"


    // $ANTLR start "ruleForStatement"
    // InternalMyGames.g:1087:1: ruleForStatement returns [EObject current=null] : (otherlv_0= 'for' otherlv_1= '(' ( (lv_iterator_2_0= ruleAssignmentStatement ) ) otherlv_3= ';' ( (lv_condition_4_0= ruleExpression ) ) otherlv_5= ';' ( (lv_iteratoroperation_6_0= ruleAssignmentStatement ) ) otherlv_7= ')' ( (lv_normalstatements_8_0= ruleNormalStatementBlock ) ) ) ;
    public final EObject ruleForStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        EObject lv_iterator_2_0 = null;

        EObject lv_condition_4_0 = null;

        EObject lv_iteratoroperation_6_0 = null;

        EObject lv_normalstatements_8_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1093:2: ( (otherlv_0= 'for' otherlv_1= '(' ( (lv_iterator_2_0= ruleAssignmentStatement ) ) otherlv_3= ';' ( (lv_condition_4_0= ruleExpression ) ) otherlv_5= ';' ( (lv_iteratoroperation_6_0= ruleAssignmentStatement ) ) otherlv_7= ')' ( (lv_normalstatements_8_0= ruleNormalStatementBlock ) ) ) )
            // InternalMyGames.g:1094:2: (otherlv_0= 'for' otherlv_1= '(' ( (lv_iterator_2_0= ruleAssignmentStatement ) ) otherlv_3= ';' ( (lv_condition_4_0= ruleExpression ) ) otherlv_5= ';' ( (lv_iteratoroperation_6_0= ruleAssignmentStatement ) ) otherlv_7= ')' ( (lv_normalstatements_8_0= ruleNormalStatementBlock ) ) )
            {
            // InternalMyGames.g:1094:2: (otherlv_0= 'for' otherlv_1= '(' ( (lv_iterator_2_0= ruleAssignmentStatement ) ) otherlv_3= ';' ( (lv_condition_4_0= ruleExpression ) ) otherlv_5= ';' ( (lv_iteratoroperation_6_0= ruleAssignmentStatement ) ) otherlv_7= ')' ( (lv_normalstatements_8_0= ruleNormalStatementBlock ) ) )
            // InternalMyGames.g:1095:3: otherlv_0= 'for' otherlv_1= '(' ( (lv_iterator_2_0= ruleAssignmentStatement ) ) otherlv_3= ';' ( (lv_condition_4_0= ruleExpression ) ) otherlv_5= ';' ( (lv_iteratoroperation_6_0= ruleAssignmentStatement ) ) otherlv_7= ')' ( (lv_normalstatements_8_0= ruleNormalStatementBlock ) )
            {
            otherlv_0=(Token)match(input,37,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getForStatementAccess().getForKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_24); 

            			newLeafNode(otherlv_1, grammarAccess.getForStatementAccess().getLeftParenthesisKeyword_1());
            		
            // InternalMyGames.g:1103:3: ( (lv_iterator_2_0= ruleAssignmentStatement ) )
            // InternalMyGames.g:1104:4: (lv_iterator_2_0= ruleAssignmentStatement )
            {
            // InternalMyGames.g:1104:4: (lv_iterator_2_0= ruleAssignmentStatement )
            // InternalMyGames.g:1105:5: lv_iterator_2_0= ruleAssignmentStatement
            {

            					newCompositeNode(grammarAccess.getForStatementAccess().getIteratorAssignmentStatementParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_10);
            lv_iterator_2_0=ruleAssignmentStatement();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getForStatementRule());
            					}
            					set(
            						current,
            						"iterator",
            						lv_iterator_2_0,
            						"org.xtext.game.mygame.MyGames.AssignmentStatement");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,17,FOLLOW_15); 

            			newLeafNode(otherlv_3, grammarAccess.getForStatementAccess().getSemicolonKeyword_3());
            		
            // InternalMyGames.g:1126:3: ( (lv_condition_4_0= ruleExpression ) )
            // InternalMyGames.g:1127:4: (lv_condition_4_0= ruleExpression )
            {
            // InternalMyGames.g:1127:4: (lv_condition_4_0= ruleExpression )
            // InternalMyGames.g:1128:5: lv_condition_4_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getForStatementAccess().getConditionExpressionParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_10);
            lv_condition_4_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getForStatementRule());
            					}
            					set(
            						current,
            						"condition",
            						lv_condition_4_0,
            						"org.xtext.game.mygame.MyGames.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,17,FOLLOW_24); 

            			newLeafNode(otherlv_5, grammarAccess.getForStatementAccess().getSemicolonKeyword_5());
            		
            // InternalMyGames.g:1149:3: ( (lv_iteratoroperation_6_0= ruleAssignmentStatement ) )
            // InternalMyGames.g:1150:4: (lv_iteratoroperation_6_0= ruleAssignmentStatement )
            {
            // InternalMyGames.g:1150:4: (lv_iteratoroperation_6_0= ruleAssignmentStatement )
            // InternalMyGames.g:1151:5: lv_iteratoroperation_6_0= ruleAssignmentStatement
            {

            					newCompositeNode(grammarAccess.getForStatementAccess().getIteratoroperationAssignmentStatementParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_22);
            lv_iteratoroperation_6_0=ruleAssignmentStatement();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getForStatementRule());
            					}
            					set(
            						current,
            						"iteratoroperation",
            						lv_iteratoroperation_6_0,
            						"org.xtext.game.mygame.MyGames.AssignmentStatement");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_7=(Token)match(input,15,FOLLOW_8); 

            			newLeafNode(otherlv_7, grammarAccess.getForStatementAccess().getRightParenthesisKeyword_7());
            		
            // InternalMyGames.g:1172:3: ( (lv_normalstatements_8_0= ruleNormalStatementBlock ) )
            // InternalMyGames.g:1173:4: (lv_normalstatements_8_0= ruleNormalStatementBlock )
            {
            // InternalMyGames.g:1173:4: (lv_normalstatements_8_0= ruleNormalStatementBlock )
            // InternalMyGames.g:1174:5: lv_normalstatements_8_0= ruleNormalStatementBlock
            {

            					newCompositeNode(grammarAccess.getForStatementAccess().getNormalstatementsNormalStatementBlockParserRuleCall_8_0());
            				
            pushFollow(FOLLOW_2);
            lv_normalstatements_8_0=ruleNormalStatementBlock();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getForStatementRule());
            					}
            					set(
            						current,
            						"normalstatements",
            						lv_normalstatements_8_0,
            						"org.xtext.game.mygame.MyGames.NormalStatementBlock");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleForStatement"


    // $ANTLR start "entryRuleExpression"
    // InternalMyGames.g:1195:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalMyGames.g:1195:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalMyGames.g:1196:2: iv_ruleExpression= ruleExpression EOF
            {
             newCompositeNode(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;

             current =iv_ruleExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalMyGames.g:1202:1: ruleExpression returns [EObject current=null] : this_RelationExpression_0= ruleRelationExpression ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_RelationExpression_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1208:2: (this_RelationExpression_0= ruleRelationExpression )
            // InternalMyGames.g:1209:2: this_RelationExpression_0= ruleRelationExpression
            {

            		newCompositeNode(grammarAccess.getExpressionAccess().getRelationExpressionParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_RelationExpression_0=ruleRelationExpression();

            state._fsp--;


            		current = this_RelationExpression_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleRelationExpression"
    // InternalMyGames.g:1220:1: entryRuleRelationExpression returns [EObject current=null] : iv_ruleRelationExpression= ruleRelationExpression EOF ;
    public final EObject entryRuleRelationExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRelationExpression = null;


        try {
            // InternalMyGames.g:1220:59: (iv_ruleRelationExpression= ruleRelationExpression EOF )
            // InternalMyGames.g:1221:2: iv_ruleRelationExpression= ruleRelationExpression EOF
            {
             newCompositeNode(grammarAccess.getRelationExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRelationExpression=ruleRelationExpression();

            state._fsp--;

             current =iv_ruleRelationExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRelationExpression"


    // $ANTLR start "ruleRelationExpression"
    // InternalMyGames.g:1227:1: ruleRelationExpression returns [EObject current=null] : (this_AdditionExpression_0= ruleAdditionExpression ( ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) ) )* ) ;
    public final EObject ruleRelationExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject this_AdditionExpression_0 = null;

        EObject lv_right_5_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1233:2: ( (this_AdditionExpression_0= ruleAdditionExpression ( ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) ) )* ) )
            // InternalMyGames.g:1234:2: (this_AdditionExpression_0= ruleAdditionExpression ( ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) ) )* )
            {
            // InternalMyGames.g:1234:2: (this_AdditionExpression_0= ruleAdditionExpression ( ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) ) )* )
            // InternalMyGames.g:1235:3: this_AdditionExpression_0= ruleAdditionExpression ( ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) ) )*
            {

            			newCompositeNode(grammarAccess.getRelationExpressionAccess().getAdditionExpressionParserRuleCall_0());
            		
            pushFollow(FOLLOW_25);
            this_AdditionExpression_0=ruleAdditionExpression();

            state._fsp--;


            			current = this_AdditionExpression_0;
            			afterParserOrEnumRuleCall();
            		
            // InternalMyGames.g:1243:3: ( ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) ) )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( ((LA18_0>=38 && LA18_0<=39)) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalMyGames.g:1244:4: ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) ) ( (lv_right_5_0= ruleAdditionExpression ) )
            	    {
            	    // InternalMyGames.g:1244:4: ( ( () otherlv_2= '==' ) | ( () otherlv_4= '<' ) )
            	    int alt17=2;
            	    int LA17_0 = input.LA(1);

            	    if ( (LA17_0==38) ) {
            	        alt17=1;
            	    }
            	    else if ( (LA17_0==39) ) {
            	        alt17=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 17, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt17) {
            	        case 1 :
            	            // InternalMyGames.g:1245:5: ( () otherlv_2= '==' )
            	            {
            	            // InternalMyGames.g:1245:5: ( () otherlv_2= '==' )
            	            // InternalMyGames.g:1246:6: () otherlv_2= '=='
            	            {
            	            // InternalMyGames.g:1246:6: ()
            	            // InternalMyGames.g:1247:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getRelationExpressionAccess().getEqualsLeftAction_1_0_0_0(),
            	            								current);
            	            						

            	            }

            	            otherlv_2=(Token)match(input,38,FOLLOW_15); 

            	            						newLeafNode(otherlv_2, grammarAccess.getRelationExpressionAccess().getEqualsSignEqualsSignKeyword_1_0_0_1());
            	            					

            	            }


            	            }
            	            break;
            	        case 2 :
            	            // InternalMyGames.g:1259:5: ( () otherlv_4= '<' )
            	            {
            	            // InternalMyGames.g:1259:5: ( () otherlv_4= '<' )
            	            // InternalMyGames.g:1260:6: () otherlv_4= '<'
            	            {
            	            // InternalMyGames.g:1260:6: ()
            	            // InternalMyGames.g:1261:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getRelationExpressionAccess().getLessLeftAction_1_0_1_0(),
            	            								current);
            	            						

            	            }

            	            otherlv_4=(Token)match(input,39,FOLLOW_15); 

            	            						newLeafNode(otherlv_4, grammarAccess.getRelationExpressionAccess().getLessThanSignKeyword_1_0_1_1());
            	            					

            	            }


            	            }
            	            break;

            	    }

            	    // InternalMyGames.g:1273:4: ( (lv_right_5_0= ruleAdditionExpression ) )
            	    // InternalMyGames.g:1274:5: (lv_right_5_0= ruleAdditionExpression )
            	    {
            	    // InternalMyGames.g:1274:5: (lv_right_5_0= ruleAdditionExpression )
            	    // InternalMyGames.g:1275:6: lv_right_5_0= ruleAdditionExpression
            	    {

            	    						newCompositeNode(grammarAccess.getRelationExpressionAccess().getRightAdditionExpressionParserRuleCall_1_1_0());
            	    					
            	    pushFollow(FOLLOW_25);
            	    lv_right_5_0=ruleAdditionExpression();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getRelationExpressionRule());
            	    						}
            	    						set(
            	    							current,
            	    							"right",
            	    							lv_right_5_0,
            	    							"org.xtext.game.mygame.MyGames.AdditionExpression");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRelationExpression"


    // $ANTLR start "entryRuleAdditionExpression"
    // InternalMyGames.g:1297:1: entryRuleAdditionExpression returns [EObject current=null] : iv_ruleAdditionExpression= ruleAdditionExpression EOF ;
    public final EObject entryRuleAdditionExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAdditionExpression = null;


        try {
            // InternalMyGames.g:1297:59: (iv_ruleAdditionExpression= ruleAdditionExpression EOF )
            // InternalMyGames.g:1298:2: iv_ruleAdditionExpression= ruleAdditionExpression EOF
            {
             newCompositeNode(grammarAccess.getAdditionExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAdditionExpression=ruleAdditionExpression();

            state._fsp--;

             current =iv_ruleAdditionExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAdditionExpression"


    // $ANTLR start "ruleAdditionExpression"
    // InternalMyGames.g:1304:1: ruleAdditionExpression returns [EObject current=null] : (this_MultiplyExpression_0= ruleMultiplyExpression ( ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) ) )* ) ;
    public final EObject ruleAdditionExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject this_MultiplyExpression_0 = null;

        EObject lv_right_5_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1310:2: ( (this_MultiplyExpression_0= ruleMultiplyExpression ( ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) ) )* ) )
            // InternalMyGames.g:1311:2: (this_MultiplyExpression_0= ruleMultiplyExpression ( ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) ) )* )
            {
            // InternalMyGames.g:1311:2: (this_MultiplyExpression_0= ruleMultiplyExpression ( ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) ) )* )
            // InternalMyGames.g:1312:3: this_MultiplyExpression_0= ruleMultiplyExpression ( ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) ) )*
            {

            			newCompositeNode(grammarAccess.getAdditionExpressionAccess().getMultiplyExpressionParserRuleCall_0());
            		
            pushFollow(FOLLOW_26);
            this_MultiplyExpression_0=ruleMultiplyExpression();

            state._fsp--;


            			current = this_MultiplyExpression_0;
            			afterParserOrEnumRuleCall();
            		
            // InternalMyGames.g:1320:3: ( ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) ) )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( ((LA20_0>=40 && LA20_0<=41)) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalMyGames.g:1321:4: ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) ) ( (lv_right_5_0= ruleMultiplyExpression ) )
            	    {
            	    // InternalMyGames.g:1321:4: ( ( () otherlv_2= '+' ) | ( () otherlv_4= '-' ) )
            	    int alt19=2;
            	    int LA19_0 = input.LA(1);

            	    if ( (LA19_0==40) ) {
            	        alt19=1;
            	    }
            	    else if ( (LA19_0==41) ) {
            	        alt19=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 19, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt19) {
            	        case 1 :
            	            // InternalMyGames.g:1322:5: ( () otherlv_2= '+' )
            	            {
            	            // InternalMyGames.g:1322:5: ( () otherlv_2= '+' )
            	            // InternalMyGames.g:1323:6: () otherlv_2= '+'
            	            {
            	            // InternalMyGames.g:1323:6: ()
            	            // InternalMyGames.g:1324:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getAdditionExpressionAccess().getAddLeftAction_1_0_0_0(),
            	            								current);
            	            						

            	            }

            	            otherlv_2=(Token)match(input,40,FOLLOW_15); 

            	            						newLeafNode(otherlv_2, grammarAccess.getAdditionExpressionAccess().getPlusSignKeyword_1_0_0_1());
            	            					

            	            }


            	            }
            	            break;
            	        case 2 :
            	            // InternalMyGames.g:1336:5: ( () otherlv_4= '-' )
            	            {
            	            // InternalMyGames.g:1336:5: ( () otherlv_4= '-' )
            	            // InternalMyGames.g:1337:6: () otherlv_4= '-'
            	            {
            	            // InternalMyGames.g:1337:6: ()
            	            // InternalMyGames.g:1338:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getAdditionExpressionAccess().getMinusLeftAction_1_0_1_0(),
            	            								current);
            	            						

            	            }

            	            otherlv_4=(Token)match(input,41,FOLLOW_15); 

            	            						newLeafNode(otherlv_4, grammarAccess.getAdditionExpressionAccess().getHyphenMinusKeyword_1_0_1_1());
            	            					

            	            }


            	            }
            	            break;

            	    }

            	    // InternalMyGames.g:1350:4: ( (lv_right_5_0= ruleMultiplyExpression ) )
            	    // InternalMyGames.g:1351:5: (lv_right_5_0= ruleMultiplyExpression )
            	    {
            	    // InternalMyGames.g:1351:5: (lv_right_5_0= ruleMultiplyExpression )
            	    // InternalMyGames.g:1352:6: lv_right_5_0= ruleMultiplyExpression
            	    {

            	    						newCompositeNode(grammarAccess.getAdditionExpressionAccess().getRightMultiplyExpressionParserRuleCall_1_1_0());
            	    					
            	    pushFollow(FOLLOW_26);
            	    lv_right_5_0=ruleMultiplyExpression();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getAdditionExpressionRule());
            	    						}
            	    						set(
            	    							current,
            	    							"right",
            	    							lv_right_5_0,
            	    							"org.xtext.game.mygame.MyGames.MultiplyExpression");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAdditionExpression"


    // $ANTLR start "entryRuleMultiplyExpression"
    // InternalMyGames.g:1374:1: entryRuleMultiplyExpression returns [EObject current=null] : iv_ruleMultiplyExpression= ruleMultiplyExpression EOF ;
    public final EObject entryRuleMultiplyExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMultiplyExpression = null;


        try {
            // InternalMyGames.g:1374:59: (iv_ruleMultiplyExpression= ruleMultiplyExpression EOF )
            // InternalMyGames.g:1375:2: iv_ruleMultiplyExpression= ruleMultiplyExpression EOF
            {
             newCompositeNode(grammarAccess.getMultiplyExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMultiplyExpression=ruleMultiplyExpression();

            state._fsp--;

             current =iv_ruleMultiplyExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMultiplyExpression"


    // $ANTLR start "ruleMultiplyExpression"
    // InternalMyGames.g:1381:1: ruleMultiplyExpression returns [EObject current=null] : (this_NegationExpression_0= ruleNegationExpression ( ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) ) )* ) ;
    public final EObject ruleMultiplyExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject this_NegationExpression_0 = null;

        EObject lv_right_5_0 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1387:2: ( (this_NegationExpression_0= ruleNegationExpression ( ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) ) )* ) )
            // InternalMyGames.g:1388:2: (this_NegationExpression_0= ruleNegationExpression ( ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) ) )* )
            {
            // InternalMyGames.g:1388:2: (this_NegationExpression_0= ruleNegationExpression ( ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) ) )* )
            // InternalMyGames.g:1389:3: this_NegationExpression_0= ruleNegationExpression ( ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) ) )*
            {

            			newCompositeNode(grammarAccess.getMultiplyExpressionAccess().getNegationExpressionParserRuleCall_0());
            		
            pushFollow(FOLLOW_27);
            this_NegationExpression_0=ruleNegationExpression();

            state._fsp--;


            			current = this_NegationExpression_0;
            			afterParserOrEnumRuleCall();
            		
            // InternalMyGames.g:1397:3: ( ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) ) )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( ((LA22_0>=42 && LA22_0<=43)) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // InternalMyGames.g:1398:4: ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) ) ( (lv_right_5_0= ruleNegationExpression ) )
            	    {
            	    // InternalMyGames.g:1398:4: ( ( () otherlv_2= '/' ) | ( () otherlv_4= '*' ) )
            	    int alt21=2;
            	    int LA21_0 = input.LA(1);

            	    if ( (LA21_0==42) ) {
            	        alt21=1;
            	    }
            	    else if ( (LA21_0==43) ) {
            	        alt21=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 21, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt21) {
            	        case 1 :
            	            // InternalMyGames.g:1399:5: ( () otherlv_2= '/' )
            	            {
            	            // InternalMyGames.g:1399:5: ( () otherlv_2= '/' )
            	            // InternalMyGames.g:1400:6: () otherlv_2= '/'
            	            {
            	            // InternalMyGames.g:1400:6: ()
            	            // InternalMyGames.g:1401:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getMultiplyExpressionAccess().getDivideLeftAction_1_0_0_0(),
            	            								current);
            	            						

            	            }

            	            otherlv_2=(Token)match(input,42,FOLLOW_15); 

            	            						newLeafNode(otherlv_2, grammarAccess.getMultiplyExpressionAccess().getSolidusKeyword_1_0_0_1());
            	            					

            	            }


            	            }
            	            break;
            	        case 2 :
            	            // InternalMyGames.g:1413:5: ( () otherlv_4= '*' )
            	            {
            	            // InternalMyGames.g:1413:5: ( () otherlv_4= '*' )
            	            // InternalMyGames.g:1414:6: () otherlv_4= '*'
            	            {
            	            // InternalMyGames.g:1414:6: ()
            	            // InternalMyGames.g:1415:7: 
            	            {

            	            							current = forceCreateModelElementAndSet(
            	            								grammarAccess.getMultiplyExpressionAccess().getMultiplyLeftAction_1_0_1_0(),
            	            								current);
            	            						

            	            }

            	            otherlv_4=(Token)match(input,43,FOLLOW_15); 

            	            						newLeafNode(otherlv_4, grammarAccess.getMultiplyExpressionAccess().getAsteriskKeyword_1_0_1_1());
            	            					

            	            }


            	            }
            	            break;

            	    }

            	    // InternalMyGames.g:1427:4: ( (lv_right_5_0= ruleNegationExpression ) )
            	    // InternalMyGames.g:1428:5: (lv_right_5_0= ruleNegationExpression )
            	    {
            	    // InternalMyGames.g:1428:5: (lv_right_5_0= ruleNegationExpression )
            	    // InternalMyGames.g:1429:6: lv_right_5_0= ruleNegationExpression
            	    {

            	    						newCompositeNode(grammarAccess.getMultiplyExpressionAccess().getRightNegationExpressionParserRuleCall_1_1_0());
            	    					
            	    pushFollow(FOLLOW_27);
            	    lv_right_5_0=ruleNegationExpression();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getMultiplyExpressionRule());
            	    						}
            	    						set(
            	    							current,
            	    							"right",
            	    							lv_right_5_0,
            	    							"org.xtext.game.mygame.MyGames.NegationExpression");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMultiplyExpression"


    // $ANTLR start "entryRuleNegationExpression"
    // InternalMyGames.g:1451:1: entryRuleNegationExpression returns [EObject current=null] : iv_ruleNegationExpression= ruleNegationExpression EOF ;
    public final EObject entryRuleNegationExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNegationExpression = null;


        try {
            // InternalMyGames.g:1451:59: (iv_ruleNegationExpression= ruleNegationExpression EOF )
            // InternalMyGames.g:1452:2: iv_ruleNegationExpression= ruleNegationExpression EOF
            {
             newCompositeNode(grammarAccess.getNegationExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNegationExpression=ruleNegationExpression();

            state._fsp--;

             current =iv_ruleNegationExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNegationExpression"


    // $ANTLR start "ruleNegationExpression"
    // InternalMyGames.g:1458:1: ruleNegationExpression returns [EObject current=null] : ( ( ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) ) ) | this_BoolExpression_3= ruleBoolExpression ) ;
    public final EObject ruleNegationExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_expression_2_0 = null;

        EObject this_BoolExpression_3 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1464:2: ( ( ( ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) ) ) | this_BoolExpression_3= ruleBoolExpression ) )
            // InternalMyGames.g:1465:2: ( ( ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) ) ) | this_BoolExpression_3= ruleBoolExpression )
            {
            // InternalMyGames.g:1465:2: ( ( ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) ) ) | this_BoolExpression_3= ruleBoolExpression )
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==44) ) {
                alt23=1;
            }
            else if ( ((LA23_0>=RULE_ID && LA23_0<=RULE_NUMBER)||LA23_0==13) ) {
                alt23=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }
            switch (alt23) {
                case 1 :
                    // InternalMyGames.g:1466:3: ( ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) ) )
                    {
                    // InternalMyGames.g:1466:3: ( ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) ) )
                    // InternalMyGames.g:1467:4: ( () otherlv_1= '!' ) ( (lv_expression_2_0= ruleNegationExpression ) )
                    {
                    // InternalMyGames.g:1467:4: ( () otherlv_1= '!' )
                    // InternalMyGames.g:1468:5: () otherlv_1= '!'
                    {
                    // InternalMyGames.g:1468:5: ()
                    // InternalMyGames.g:1469:6: 
                    {

                    						current = forceCreateModelElement(
                    							grammarAccess.getNegationExpressionAccess().getNegationAction_0_0_0(),
                    							current);
                    					

                    }

                    otherlv_1=(Token)match(input,44,FOLLOW_15); 

                    					newLeafNode(otherlv_1, grammarAccess.getNegationExpressionAccess().getExclamationMarkKeyword_0_0_1());
                    				

                    }

                    // InternalMyGames.g:1480:4: ( (lv_expression_2_0= ruleNegationExpression ) )
                    // InternalMyGames.g:1481:5: (lv_expression_2_0= ruleNegationExpression )
                    {
                    // InternalMyGames.g:1481:5: (lv_expression_2_0= ruleNegationExpression )
                    // InternalMyGames.g:1482:6: lv_expression_2_0= ruleNegationExpression
                    {

                    						newCompositeNode(grammarAccess.getNegationExpressionAccess().getExpressionNegationExpressionParserRuleCall_0_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_expression_2_0=ruleNegationExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getNegationExpressionRule());
                    						}
                    						set(
                    							current,
                    							"expression",
                    							lv_expression_2_0,
                    							"org.xtext.game.mygame.MyGames.NegationExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyGames.g:1501:3: this_BoolExpression_3= ruleBoolExpression
                    {

                    			newCompositeNode(grammarAccess.getNegationExpressionAccess().getBoolExpressionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_BoolExpression_3=ruleBoolExpression();

                    state._fsp--;


                    			current = this_BoolExpression_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNegationExpression"


    // $ANTLR start "entryRuleBoolExpression"
    // InternalMyGames.g:1513:1: entryRuleBoolExpression returns [EObject current=null] : iv_ruleBoolExpression= ruleBoolExpression EOF ;
    public final EObject entryRuleBoolExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBoolExpression = null;


        try {
            // InternalMyGames.g:1513:55: (iv_ruleBoolExpression= ruleBoolExpression EOF )
            // InternalMyGames.g:1514:2: iv_ruleBoolExpression= ruleBoolExpression EOF
            {
             newCompositeNode(grammarAccess.getBoolExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBoolExpression=ruleBoolExpression();

            state._fsp--;

             current =iv_ruleBoolExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBoolExpression"


    // $ANTLR start "ruleBoolExpression"
    // InternalMyGames.g:1520:1: ruleBoolExpression returns [EObject current=null] : ( ( () ( (lv_value_1_0= RULE_NUMBER ) ) ) | this_Varaible_2= ruleVaraible | (otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')' ) ) ;
    public final EObject ruleBoolExpression() throws RecognitionException {
        EObject current = null;

        Token lv_value_1_0=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        EObject this_Varaible_2 = null;

        EObject this_Expression_4 = null;



        	enterRule();

        try {
            // InternalMyGames.g:1526:2: ( ( ( () ( (lv_value_1_0= RULE_NUMBER ) ) ) | this_Varaible_2= ruleVaraible | (otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')' ) ) )
            // InternalMyGames.g:1527:2: ( ( () ( (lv_value_1_0= RULE_NUMBER ) ) ) | this_Varaible_2= ruleVaraible | (otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')' ) )
            {
            // InternalMyGames.g:1527:2: ( ( () ( (lv_value_1_0= RULE_NUMBER ) ) ) | this_Varaible_2= ruleVaraible | (otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')' ) )
            int alt24=3;
            switch ( input.LA(1) ) {
            case RULE_NUMBER:
                {
                alt24=1;
                }
                break;
            case RULE_ID:
                {
                alt24=2;
                }
                break;
            case 13:
                {
                alt24=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }

            switch (alt24) {
                case 1 :
                    // InternalMyGames.g:1528:3: ( () ( (lv_value_1_0= RULE_NUMBER ) ) )
                    {
                    // InternalMyGames.g:1528:3: ( () ( (lv_value_1_0= RULE_NUMBER ) ) )
                    // InternalMyGames.g:1529:4: () ( (lv_value_1_0= RULE_NUMBER ) )
                    {
                    // InternalMyGames.g:1529:4: ()
                    // InternalMyGames.g:1530:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getBoolExpressionAccess().getNumberLiteralAction_0_0(),
                    						current);
                    				

                    }

                    // InternalMyGames.g:1536:4: ( (lv_value_1_0= RULE_NUMBER ) )
                    // InternalMyGames.g:1537:5: (lv_value_1_0= RULE_NUMBER )
                    {
                    // InternalMyGames.g:1537:5: (lv_value_1_0= RULE_NUMBER )
                    // InternalMyGames.g:1538:6: lv_value_1_0= RULE_NUMBER
                    {
                    lv_value_1_0=(Token)match(input,RULE_NUMBER,FOLLOW_2); 

                    						newLeafNode(lv_value_1_0, grammarAccess.getBoolExpressionAccess().getValueNUMBERTerminalRuleCall_0_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getBoolExpressionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"value",
                    							lv_value_1_0,
                    							"org.xtext.game.mygame.MyGames.NUMBER");
                    					

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyGames.g:1556:3: this_Varaible_2= ruleVaraible
                    {

                    			newCompositeNode(grammarAccess.getBoolExpressionAccess().getVaraibleParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Varaible_2=ruleVaraible();

                    state._fsp--;


                    			current = this_Varaible_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMyGames.g:1565:3: (otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')' )
                    {
                    // InternalMyGames.g:1565:3: (otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')' )
                    // InternalMyGames.g:1566:4: otherlv_3= '(' this_Expression_4= ruleExpression otherlv_5= ')'
                    {
                    otherlv_3=(Token)match(input,13,FOLLOW_15); 

                    				newLeafNode(otherlv_3, grammarAccess.getBoolExpressionAccess().getLeftParenthesisKeyword_2_0());
                    			

                    				newCompositeNode(grammarAccess.getBoolExpressionAccess().getExpressionParserRuleCall_2_1());
                    			
                    pushFollow(FOLLOW_22);
                    this_Expression_4=ruleExpression();

                    state._fsp--;


                    				current = this_Expression_4;
                    				afterParserOrEnumRuleCall();
                    			
                    otherlv_5=(Token)match(input,15,FOLLOW_2); 

                    				newLeafNode(otherlv_5, grammarAccess.getBoolExpressionAccess().getRightParenthesisKeyword_2_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBoolExpression"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000008010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x000000000000C000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000002F10000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000042000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000100000002030L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000001000002L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x00000000F0000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000002A00000010L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000400040002L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000400000002L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000001000000002L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000002800000010L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x000000C000000002L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000030000000002L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x00000C0000000002L});

}